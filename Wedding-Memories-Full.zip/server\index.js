import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import QRCode from "qrcode";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "data.json");
const UPLOADS = path.join(__dirname, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });
const SECRET = process.env.JWT_SECRET || "replace-this-secret-before-deploying";

const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: "2mb" }));
app.use("/uploads", express.static(UPLOADS));

const DEFAULT_SERVICES = [
  { name: "Traditional Wedding Photography", price: 15000, enabled: true },
  { name: "Cinematic Videography & Teaser", price: 25000, enabled: true },
  { name: "Pre-Wedding Couple Shoot", price: 15000, enabled: true },
  { name: "Car Opening & Grand Entry Video", price: 12000, enabled: true },
  { name: "Drone Aerial Shoot", price: 10000, enabled: true },
  { name: "Premium Hardcover Photo Album", price: 12000, enabled: true },
  { name: "Haldi, Sangeet & Pre-Shoot Coverage", price: 18000, enabled: true },
  { name: "Live Event Streaming (YouTube/LED)", price: 15000, enabled: false }
];

const DEFAULT_HOME_CONTENT = {
  heroEyebrow: "CAPTURING YOUR LOVE STORY",
  heroTitle: "Every Moment Deserves to be Remembered",
  heroSubtitle: "Capturing your beautiful stories, one frame at a time.",
  heroBgImage: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1800",
  heroButtonText1: "Explore Our Work",
  heroButtonText2: "Book Your Date",
  featureEyebrow: "OUR EXPERTISE",
  featureTitle: "Photography Services Made Timeless",
  card1Title: "Wedding Photography",
  card1Desc: "Honest emotional moments, candid portraits, and traditional ceremony rituals.",
  card2Title: "Cinematic Films",
  card2Desc: "4K movie-style wedding films, emotional teasers, and color-graded highlights.",
  card3Title: "QR Photo Gallery",
  card3Desc: "Scan, view, and download wedding photos instantly via private QR codes.",
  ctaEyebrow: "YOUR DAY, YOUR STORY",
  ctaTitle: "One beautiful day. A lifetime of memories.",
  ctaButtonText: "Book Your Date & Request Quotation"
};

const initial = { users: [], quotations: [], weddings: [], photos: [], scans: [], showcasePhotos: [], homeContent: DEFAULT_HOME_CONTENT };
function read() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA, "utf8"));
    if (!Array.isArray(data.users)) data.users = [];
    if (!Array.isArray(data.quotations)) data.quotations = [];
    if (!Array.isArray(data.weddings)) data.weddings = [];
    if (!Array.isArray(data.photos)) data.photos = [];
    if (!Array.isArray(data.scans)) data.scans = [];
    if (!Array.isArray(data.showcasePhotos)) data.showcasePhotos = [];
    if (!data.homeContent) data.homeContent = { ...DEFAULT_HOME_CONTENT };
    return data;
  } catch {
    return structuredClone(initial);
  }
}
function write(db) { fs.writeFileSync(DATA, JSON.stringify(db, null, 2)); }
let db = read();

async function seedOwner() {
  const adminEmail = "bhaveshshewale76@gmail.com";
  let owner = db.users.find(u => u.email.toLowerCase() === adminEmail || u.role === "owner" || u.role === "admin");
  const hashed = "$2a$10$BNNHfG9eGgg5/fsqBIe4se1BiU.zT7V/TFyobrPtHwsesZ10UTDuy";
  if (!owner) {
    owner = {
      id: crypto.randomUUID(),
      name: "Bhavesh Shewale",
      email: adminEmail,
      password: hashed,
      role: "admin",
      createdAt: new Date().toISOString()
    };
    db.users.push(owner);
    write(db);
  } else {
    owner.name = "Bhavesh Shewale";
    owner.email = adminEmail;
    owner.password = hashed;
    owner.role = "admin";
    write(db);
  }
}
await seedOwner();

function evalSubscription(u) {
  if (!u || u.role !== "photographer") return u;

  const now = new Date();

  // Auto migration for older photographer records created before subscription system
  if (!u.subscriptionStartDate) {
    u.subscriptionStartDate = u.joiningDate || (u.createdAt ? u.createdAt.split("T")[0] : now.toISOString().split("T")[0]);
  }

  if (!u.subscriptionEndDate) {
    const startDt = new Date(u.subscriptionStartDate);
    if (!isNaN(startDt.getTime())) {
      const endDt = new Date(startDt.getTime() + (30 * 24 * 60 * 60 * 1000));
      u.subscriptionEndDate = endDt.toISOString().split("T")[0];
    } else {
      u.subscriptionStartDate = now.toISOString().split("T")[0];
      u.subscriptionEndDate = new Date(now.getTime() + (30 * 24 * 60 * 60 * 1000)).toISOString().split("T")[0];
    }
  }

  if (!u.planType) u.planType = "Monthly";
  if (!u.amount) u.amount = 999;
  if (!u.lastPaymentDate) u.lastPaymentDate = u.subscriptionStartDate;
  if (!Array.isArray(u.paymentHistory)) {
    u.paymentHistory = [{
      id: crypto.randomUUID(),
      date: u.subscriptionStartDate,
      amount: u.amount,
      renewedBy: "System Migration",
      paymentMode: "Cash",
      notes: "Initial Subscription"
    }];
  }

  if (u.isActive === false) {
    u.subscriptionStatus = "deactivated";
    u.daysLeft = 0;
    return u;
  }

  const endDate = new Date(u.subscriptionEndDate);

  if (isNaN(endDate.getTime())) {
    u.subscriptionStatus = "expired";
    u.daysLeft = 0;
    return u;
  }

  const diffTime = endDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  u.daysLeft = diffDays;

  if (diffDays <= 0) {
    u.subscriptionStatus = "expired";
  } else if (diffDays <= 5) {
    u.subscriptionStatus = "expiring_soon";
  } else {
    u.subscriptionStatus = "active";
  }

  return u;
}

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({ error: "Please log in first." }); }
}

function allow(...roles) {
  return (req, res, next) => {
    const userRole = (req.user.role === "owner" || req.user.role === "admin") ? "admin" : req.user.role;
    const allowed = roles.some(r => r === userRole || (r === "admin" && req.user.role === "owner") || r === req.user.role);
    return allowed ? next() : res.status(403).json({ error: "You do not have permission." });
  };
}

function safeUser(u) {
  if (!u) return null;
  evalSubscription(u);
  const role = (u.role === "owner" || u.role === "admin") ? "admin" : u.role;
  return {
    id: u.id,
    name: u.name || "Photographer",
    email: u.email || "",
    mobile: u.mobile || "",
    studioName: u.studioName || "",
    address: u.address || "",
    city: u.city || "",
    experience: u.experience || "",
    joiningDate: u.joiningDate || "",
    profilePhoto: u.profilePhoto || "",
    logoUrl: u.logoUrl || "",
    servicesList: u.servicesList || DEFAULT_SERVICES,
    role,
    isActive: u.isActive !== false,

    subscriptionStartDate: u.subscriptionStartDate || "",
    subscriptionEndDate: u.subscriptionEndDate || "",
    planType: u.planType || "Monthly",
    amount: u.amount || 999,
    subscriptionStatus: u.subscriptionStatus || "active",
    daysLeft: u.daysLeft !== undefined ? u.daysLeft : 0,
    lastPaymentDate: u.lastPaymentDate || "",
    paymentHistory: Array.isArray(u.paymentHistory) ? u.paymentHistory : []
  };
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(5).toString("hex")}${path.extname(file.originalname).toLowerCase()}`)
});
const upload = multer({ storage, limits: { fileSize: 12 * 1024 * 1024 }, fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) });

const photoUpload = upload.fields([
  { name: "profilePhoto", maxCount: 1 },
  { name: "logo", maxCount: 1 }
]);

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Wedding Memories" }));

// Public Get Home Page Content (Hero, Cards, CTA)
app.get("/api/public/home-content", (_req, res) => {
  try {
    const content = db.homeContent ? { ...DEFAULT_HOME_CONTENT, ...db.homeContent } : DEFAULT_HOME_CONTENT;
    res.json({ content });
  } catch (err) {
    res.status(500).json({ error: "Error fetching home content." });
  }
});

// Admin Edit Home Page Content & Hero Banner Photo
app.put("/api/admin/home-content", auth, allow("admin"), upload.single("heroBgImage"), (req, res) => {
  try {
    if (!db.homeContent) db.homeContent = { ...DEFAULT_HOME_CONTENT };

    const fields = [
      "heroEyebrow", "heroTitle", "heroSubtitle", "heroButtonText1", "heroButtonText2",
      "featureEyebrow", "featureTitle", "card1Title", "card1Desc",
      "card2Title", "card2Desc", "card3Title", "card3Desc",
      "ctaEyebrow", "ctaTitle", "ctaButtonText"
    ];

    fields.forEach(f => {
      if (req.body[f] !== undefined) {
        db.homeContent[f] = String(req.body[f]).trim();
      }
    });

    if (req.file) {
      db.homeContent.heroBgImage = `/uploads/${req.file.filename}`;
    } else if (req.body.heroBgImageUrl && req.body.heroBgImageUrl.trim() !== "") {
      db.homeContent.heroBgImage = String(req.body.heroBgImageUrl).trim();
    }

    write(db);
    res.json({ content: db.homeContent, message: "Home page banner photo & content updated successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error updating home content." });
  }
});

// Direct public registration disabled (Admin creates client accounts)
app.post("/api/register", async (_req, res) => {
  res.status(403).json({ error: "Direct public registration is disabled. Please contact Admin or submit a quotation request." });
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const query = String(email || "").toLowerCase().trim();
    const user = db.users.find(u => u.email.toLowerCase() === query || (u.mobile && u.mobile === query));

    if (!user || !(await bcrypt.compare(password || "", user.password))) {
      return res.status(401).json({ error: "Incorrect email/mobile or password." });
    }

    if (user.isActive === false) {
      return res.status(403).json({ error: "Account deactivated by Admin. Please contact support." });
    }

    evalSubscription(user);

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name, email: user.email }, SECRET, { expiresIn: "7d" });
    res.json({ token, user: safeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message || "Login failed." });
  }
});

app.get("/api/me", auth, (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ error: "User not found." });
    res.json({ user: safeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error fetching profile." });
  }
});

app.put("/api/profile", auth, async (req, res) => {
  try {
    const { name, email, newPassword } = req.body || {};
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ error: "User not found." });

    if (name) user.name = String(name).trim();

    if (email && String(email).toLowerCase() !== user.email.toLowerCase()) {
      const existing = db.users.find(u => u.email.toLowerCase() === String(email).toLowerCase() && u.id !== user.id);
      if (existing) return res.status(409).json({ error: "Email address is already in use." });
      user.email = String(email).toLowerCase();
    }

    if (newPassword && String(newPassword).trim() !== "") {
      if (newPassword.length < 6) return res.status(400).json({ error: "New password must be at least 6 characters." });
      user.password = await bcrypt.hash(newPassword, 10);
    }

    write(db);
    const updatedSafe = safeUser(user);
    const token = jwt.sign({ id: user.id, role: user.role, name: user.name, email: user.email }, SECRET, { expiresIn: "7d" });
    res.json({ user: updatedSafe, token, message: "Profile updated successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error updating profile." });
  }
});

// Public Photographer Sample Portfolio Showcase Photos API
app.get("/api/public/showcase-photos", (_req, res) => {
  try {
    if (!Array.isArray(db.showcasePhotos)) db.showcasePhotos = [];

    const enriched = db.showcasePhotos.map(p => {
      const photog = db.users.find(u => u.id === p.photographerId);
      return {
        id: p.id,
        photographerId: p.photographerId,
        photographerName: photog?.name || p.photographerName || "Photographer",
        photographerStudio: photog?.studioName || photog?.name || p.photographerStudio || "Studio",
        photographerLogo: photog?.logoUrl || "",
        title: p.title || "Sample Portfolio Shot",
        category: p.category || "Wedding",
        url: p.url,
        uploadedAt: p.uploadedAt
      };
    });

    res.json({ photos: enriched });
  } catch (err) {
    res.status(500).json({ error: "Error fetching portfolio photos." });
  }
});

// Upload Photographer Sample Portfolio / Showcase Photos
app.post("/api/photographers/showcase-photos", auth, allow("photographer"), upload.array("photos", 10), (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ error: "Photographer not found." });

    evalSubscription(user);
    if (user.subscriptionStatus === "expired") {
      return res.status(402).json({ error: "Subscription expired. Please renew to upload sample portfolio photos." });
    }

    if (!Array.isArray(db.showcasePhotos)) db.showcasePhotos = [];

    const title = (req.body.title || "Sample Portfolio Photo").trim();
    const category = (req.body.category || "Wedding").trim();

    const added = (req.files || []).map(f => ({
      id: crypto.randomUUID(),
      photographerId: user.id,
      photographerName: user.name,
      photographerStudio: user.studioName || user.name,
      title,
      category,
      filename: f.filename,
      url: `/uploads/${f.filename}`,
      uploadedAt: new Date().toISOString()
    }));

    db.showcasePhotos.unshift(...added);
    write(db);
    res.status(201).json({ photos: added, message: "Sample portfolio photos uploaded successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error uploading portfolio photos." });
  }
});

// Delete Photographer Sample Portfolio Photo
app.delete("/api/photographers/showcase-photos/:id", auth, allow("photographer", "admin"), (req, res) => {
  try {
    if (!Array.isArray(db.showcasePhotos)) db.showcasePhotos = [];
    const idx = db.showcasePhotos.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: "Sample photo not found." });

    const photo = db.showcasePhotos[idx];
    if (req.user.role === "photographer" && photo.photographerId !== req.user.id) {
      return res.status(403).json({ error: "Not allowed to delete another photographer's portfolio photo." });
    }

    if (photo.filename) {
      const filepath = path.join(UPLOADS, photo.filename);
      if (fs.existsSync(filepath)) {
        try { fs.unlinkSync(filepath); } catch {}
      }
    }

    db.showcasePhotos.splice(idx, 1);
    write(db);
    res.json({ ok: true, message: "Sample portfolio photo deleted successfully." });
  } catch (err) {
    res.status(500).json({ error: "Error deleting sample photo." });
  }
});

// Get My Sample Portfolio Photos (Logged in Photographer)
app.get("/api/photographers/my-showcase-photos", auth, allow("photographer"), (req, res) => {
  try {
    if (!Array.isArray(db.showcasePhotos)) db.showcasePhotos = [];
    const myPhotos = db.showcasePhotos.filter(p => p.photographerId === req.user.id);
    res.json({ photos: myPhotos });
  } catch (err) {
    res.status(500).json({ error: "Error fetching portfolio photos." });
  }
});

// Public List of Active Photographers for Client Quotation Request Form
app.get("/api/public/photographers", (_req, res) => {
  try {
    const activePhotogs = db.users.filter(u => {
      if (u.role !== "photographer" || u.isActive === false) return false;
      evalSubscription(u);
      return u.subscriptionStatus !== "expired";
    });
    res.json({
      photographers: activePhotogs.map(u => ({
        id: u.id,
        name: u.name,
        studioName: u.studioName || u.name,
        city: u.city || "",
        logoUrl: u.logoUrl || "",
        servicesList: u.servicesList && u.servicesList.length ? u.servicesList : DEFAULT_SERVICES
      }))
    });
  } catch (err) {
    res.status(500).json({ error: "Unable to load photographers list." });
  }
});

// Photographer Services Configuration
app.put("/api/photographers/services", auth, allow("photographer"), (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ error: "Photographer user not found." });

    evalSubscription(user);
    if (user.subscriptionStatus === "expired") {
      return res.status(402).json({ error: "Subscription expired. Please renew to edit services." });
    }

    const { servicesList } = req.body || {};
    if (Array.isArray(servicesList)) {
      user.servicesList = servicesList.map(s => ({
        name: String(s.name || "").trim(),
        price: Number(s.price) || 0,
        enabled: s.enabled !== false
      }));
    }

    write(db);
    res.json({ user: safeUser(user), message: "Offered services updated successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error updating services." });
  }
});

// Photographer Logo Upload
app.post("/api/photographers/logo", auth, allow("photographer"), upload.single("logo"), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No image file provided." });
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ error: "Photographer user not found." });

    evalSubscription(user);
    if (user.subscriptionStatus === "expired") {
      return res.status(402).json({ error: "Subscription expired. Please renew to change logo." });
    }

    if (user.logoUrl && user.logoUrl.startsWith("/uploads/")) {
      const oldFilename = path.basename(user.logoUrl);
      const oldPath = path.join(UPLOADS, oldFilename);
      if (fs.existsSync(oldPath)) { try { fs.unlinkSync(oldPath); } catch {} }
    }

    user.logoUrl = `/uploads/${req.file.filename}`;
    write(db);
    res.json({ user: safeUser(user), logoUrl: user.logoUrl, message: "Business logo updated successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error uploading logo." });
  }
});

// Get Customers List (Admin only)
app.get("/api/customers", auth, allow("admin"), (_req, res) => {
  try {
    const customers = db.users.filter(u => u.role === "customer").map(safeUser);
    res.json({ customers });
  } catch (err) {
    res.status(500).json({ error: "Error fetching customers." });
  }
});

// Add Customer / Client (Admin only)
app.post("/api/customers", auth, allow("admin"), async (req, res) => {
  try {
    const { name, email, password, mobile } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: "Full name is required." });

    const cleanEmail = String(email || "").toLowerCase().trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: "A valid email address is required." });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }

    if (db.users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return res.status(409).json({ error: "Email address is already registered." });
    }

    const user = {
      id: crypto.randomUUID(),
      name: name.trim(),
      email: cleanEmail,
      mobile: String(mobile || "").trim(),
      password: await bcrypt.hash(password, 10),
      role: "customer",
      isActive: true,
      createdAt: new Date().toISOString()
    };

    db.users.push(user);
    write(db);
    res.status(201).json({ user: safeUser(user), message: "Client account created successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error creating client." });
  }
});

// Toggle Customer Active/Deactivate Status (Admin only)
app.patch("/api/customers/:id/toggle-active", auth, allow("admin"), (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.params.id && u.role === "customer");
    if (!user) return res.status(404).json({ error: "Client not found." });
    user.isActive = user.isActive === false ? true : false;
    write(db);
    res.json({ user: safeUser(user), message: `Client account ${user.isActive ? "enabled" : "disabled"} successfully.` });
  } catch (err) {
    res.status(500).json({ error: "Error toggling status." });
  }
});

// Delete Customer (Admin only)
app.delete("/api/customers/:id", auth, allow("admin"), (req, res) => {
  try {
    const idx = db.users.findIndex(u => u.id === req.params.id && u.role === "customer");
    if (idx === -1) return res.status(404).json({ error: "Customer not found." });

    db.quotations = db.quotations.filter(q => q.customerId !== req.params.id);
    db.users.splice(idx, 1);
    write(db);
    res.json({ ok: true, message: "Customer account deleted successfully." });
  } catch (err) {
    res.status(500).json({ error: "Error deleting customer." });
  }
});

app.get("/api/photographers", auth, allow("admin"), (_req, res) => {
  try {
    const photographers = db.users.filter(u => u.role === "photographer").map(safeUser);
    res.json({ photographers });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error fetching photographers." });
  }
});

app.post("/api/photographers", auth, allow("admin"), photoUpload, async (req, res) => {
  try {
    const { name, studioName, mobile, email, password, address, city, experience, joiningDate, subscriptionStartDate, amount, paymentMode } = req.body || {};

    if (!name || !name.trim()) return res.status(400).json({ error: "Full name is required." });

    const cleanMobile = String(mobile || "").trim();
    if (!cleanMobile || !/^\d{10}$/.test(cleanMobile)) {
      return res.status(400).json({ error: "Mobile number must be exactly 10 digits." });
    }

    const cleanEmail = String(email || "").toLowerCase().trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: "A valid email address is required." });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }

    if (db.users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return res.status(409).json({ error: "Email address is already registered." });
    }
    if (db.users.some(u => u.mobile === cleanMobile)) {
      return res.status(409).json({ error: "Mobile number is already registered." });
    }

    let profilePhotoUrl = "";
    let logoUrl = "";

    if (req.files?.profilePhoto?.[0]) {
      profilePhotoUrl = `/uploads/${req.files.profilePhoto[0].filename}`;
    }
    if (req.files?.logo?.[0]) {
      logoUrl = `/uploads/${req.files.logo[0].filename}`;
    }

    const startDateStr = subscriptionStartDate || new Date().toISOString().split("T")[0];
    const planAmount = Number(amount) || 999;
    const startDt = new Date(startDateStr);
    const endDt = new Date(startDt.getTime() + (30 * 24 * 60 * 60 * 1000));
    const endDateStr = endDt.toISOString().split("T")[0];

    const initialPayment = {
      id: crypto.randomUUID(),
      date: startDateStr,
      amount: planAmount,
      renewedBy: req.user.name || "Admin",
      paymentMode: paymentMode || "Cash",
      notes: "Initial Signup Subscription"
    };

    const user = {
      id: crypto.randomUUID(),
      name: name.trim(),
      studioName: (studioName || "").trim(),
      mobile: cleanMobile,
      email: cleanEmail,
      password: await bcrypt.hash(password, 10),
      address: (address || "").trim(),
      city: (city || "").trim(),
      experience: (experience || "").trim(),
      joiningDate: joiningDate || new Date().toISOString().split("T")[0],
      profilePhoto: profilePhotoUrl,
      logoUrl: logoUrl,
      servicesList: DEFAULT_SERVICES,
      role: "photographer",
      isActive: true,
      createdAt: new Date().toISOString(),

      subscriptionStartDate: startDateStr,
      subscriptionEndDate: endDateStr,
      planType: "Monthly",
      amount: planAmount,
      subscriptionStatus: "active",
      lastPaymentDate: startDateStr,
      paymentHistory: [initialPayment]
    };

    db.users.push(user);
    write(db);
    res.status(201).json({ user: safeUser(user), message: "Photographer account created with active 30-day subscription." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error creating photographer." });
  }
});

app.put("/api/photographers/:id", auth, allow("admin"), photoUpload, async (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.params.id && u.role === "photographer");
    if (!user) return res.status(404).json({ error: "Photographer not found." });

    const { name, studioName, mobile, email, password, address, city, experience, joiningDate } = req.body || {};

    if (name) user.name = String(name).trim();
    if (studioName !== undefined) user.studioName = String(studioName).trim();
    if (address !== undefined) user.address = String(address).trim();
    if (city !== undefined) user.city = String(city).trim();
    if (experience !== undefined) user.experience = String(experience).trim();
    if (joiningDate) user.joiningDate = String(joiningDate);

    if (mobile) {
      const cleanMobile = String(mobile).trim();
      if (!/^\d{10}$/.test(cleanMobile)) {
        return res.status(400).json({ error: "Mobile number must be exactly 10 digits." });
      }
      const dup = db.users.find(u => u.mobile === cleanMobile && u.id !== user.id);
      if (dup) return res.status(409).json({ error: "Mobile number is already registered to another account." });
      user.mobile = cleanMobile;
    }

    if (email) {
      const cleanEmail = String(email).toLowerCase().trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        return res.status(400).json({ error: "A valid email address is required." });
      }
      const dup = db.users.find(u => u.email.toLowerCase() === cleanEmail && u.id !== user.id);
      if (dup) return res.status(409).json({ error: "Email address is already registered to another account." });
      user.email = cleanEmail;
    }

    if (password && String(password).trim() !== "") {
      if (password.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters." });
      user.password = await bcrypt.hash(password, 10);
    }

    if (req.files?.profilePhoto?.[0]) {
      user.profilePhoto = `/uploads/${req.files.profilePhoto[0].filename}`;
    }
    if (req.files?.logo?.[0]) {
      user.logoUrl = `/uploads/${req.files.logo[0].filename}`;
    }

    write(db);
    res.json({ user: safeUser(user), message: "Photographer updated successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error updating photographer." });
  }
});

// Admin Renew Photographer Subscription
app.post("/api/photographers/:id/renew", auth, allow("admin"), (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.params.id && u.role === "photographer");
    if (!user) return res.status(404).json({ error: "Photographer not found." });

    const { amount, paymentMode, notes } = req.body || {};
    const renewAmount = Number(amount) || user.amount || 999;
    const mode = paymentMode || "UPI";

    const now = new Date();
    evalSubscription(user);

    let currentEnd = user.subscriptionEndDate ? new Date(user.subscriptionEndDate) : now;
    if (isNaN(currentEnd.getTime()) || currentEnd < now) {
      currentEnd = now;
    }

    const newEnd = new Date(currentEnd.getTime() + (30 * 24 * 60 * 60 * 1000));

    user.subscriptionStartDate = user.subscriptionStartDate || now.toISOString().split("T")[0];
    user.subscriptionEndDate = newEnd.toISOString().split("T")[0];
    user.amount = renewAmount;
    user.lastPaymentDate = now.toISOString().split("T")[0];
    user.subscriptionStatus = "active";
    user.isActive = true;

    const paymentEntry = {
      id: crypto.randomUUID(),
      date: now.toISOString().split("T")[0],
      amount: renewAmount,
      renewedBy: req.user.name || "Admin",
      paymentMode: mode,
      notes: notes || "Monthly Subscription Renewal (30 Days)"
    };

    if (!Array.isArray(user.paymentHistory)) user.paymentHistory = [];
    user.paymentHistory.unshift(paymentEntry);

    write(db);
    res.json({ user: safeUser(user), message: `Subscription renewed successfully! Valid until ${user.subscriptionEndDate}.` });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error renewing subscription." });
  }
});

app.patch("/api/photographers/:id/toggle-active", auth, allow("admin"), (req, res) => {
  try {
    const user = db.users.find(u => u.id === req.params.id && u.role === "photographer");
    if (!user) return res.status(404).json({ error: "Photographer not found." });
    user.isActive = user.isActive === false ? true : false;
    write(db);
    res.json({ user: safeUser(user), message: `Photographer ${user.isActive ? "activated" : "deactivated"} successfully.` });
  } catch (err) {
    res.status(500).json({ error: "Error toggling photographer status." });
  }
});

app.delete("/api/photographers/:id", auth, allow("admin"), (req, res) => {
  try {
    const idx = db.users.findIndex(u => u.id === req.params.id && u.role === "photographer");
    if (idx === -1) return res.status(404).json({ error: "Photographer not found." });

    db.showcasePhotos = (db.showcasePhotos || []).filter(p => p.photographerId !== req.params.id);
    db.users.splice(idx, 1);
    write(db);
    res.json({ ok: true, message: "Photographer deleted successfully." });
  } catch (err) {
    res.status(500).json({ error: "Error deleting photographer." });
  }
});

// Public Quotation Request submission
app.post("/api/quotations", async (req, res) => {
  try {
    const { eventDate, venue, services, notes, phone, photographerId, selectedServices, customerName, email } = req.body || {};
    if (!eventDate || !venue) return res.status(400).json({ error: "Event date and venue are required." });

    let reqUser = null;
    const tokenHeader = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    if (tokenHeader) {
      try { reqUser = jwt.verify(tokenHeader, SECRET); } catch {}
    }

    const photog = photographerId ? db.users.find(u => u.id === photographerId) : null;
    const chosenServices = Array.isArray(selectedServices) && selectedServices.length > 0
      ? selectedServices
      : (Array.isArray(services) ? services : [services || "Traditional Wedding Photography"]);

    const photogServices = photog?.servicesList || DEFAULT_SERVICES;
    const initialServiceList = chosenServices.map(srvName => {
      const found = photogServices.find(s => s.name.toLowerCase() === srvName.toLowerCase());
      return {
        name: srvName,
        price: found ? found.price : 15000,
        enabled: true
      };
    });

    const q = {
      id: crypto.randomUUID(),
      customerId: reqUser ? reqUser.id : "guest",
      customerName: (customerName || reqUser?.name || "Client Inquiry").trim(),
      email: (email || reqUser?.email || "").trim(),
      phone: (phone || "").trim(),
      eventDate,
      venue,
      services: chosenServices.join(", "),
      notes: notes || "",
      status: "New",
      photographerId: photographerId || null,
      viewedAt: null,
      createdAt: new Date().toISOString(),
      customization: {
        studioName: photog?.studioName || photog?.name || "Wedding Memories Studio",
        showStudioInfo: true,
        packageName: "Selected Wedding Package",
        packageDescription: "Coverage and services selected by customer.",
        showPackageDetails: true,
        servicesList: initialServiceList,
        discount: 0,
        advanceAmount: 0,
        terms: "1. 50% advance to confirm booking.\n2. Raw photos delivered within 48 hours.\n3. Final album & video delivered within 3 weeks.",
        contactPhone: photog?.mobile || "",
        contactEmail: photog?.email || "",
        updatedAt: new Date().toISOString()
      }
    };
    db.quotations.unshift(q); write(db); res.status(201).json({ quotation: q, message: "Quotation request submitted successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error submitting quotation request." });
  }
});

app.get("/api/quotations", auth, (req, res) => {
  try {
    let items;
    if (req.user.role === "owner" || req.user.role === "admin") {
      items = db.quotations;
    } else if (req.user.role === "photographer") {
      items = db.quotations.filter(q => !q.photographerId || q.photographerId === req.user.id);
    } else {
      items = db.quotations.filter(q => q.customerId === req.user.id);
    }

    const enriched = items.map(q => {
      const photogId = q.photographerId || (req.user.role === "photographer" ? req.user.id : null);
      const photog = db.users.find(u => u.id === photogId);
      return {
        ...q,
        photographerLogo: photog?.logoUrl || "",
        photographerName: photog?.name || "",
        photographerStudio: photog?.studioName || photog?.name || ""
      };
    });

    res.json({ quotations: enriched });
  } catch (err) {
    res.status(500).json({ error: "Error fetching quotations." });
  }
});

app.delete("/api/quotations/:id", auth, allow("admin", "photographer"), (req, res) => {
  try {
    const idx = db.quotations.findIndex(q => q.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: "Quotation not found." });
    const q = db.quotations[idx];
    if (req.user.role === "photographer" && q.photographerId && q.photographerId !== req.user.id) {
      return res.status(403).json({ error: "Not allowed to delete another photographer's quotation." });
    }
    db.quotations.splice(idx, 1);
    write(db);
    res.json({ ok: true, message: "Quotation request deleted successfully." });
  } catch (err) {
    res.status(500).json({ error: "Error deleting quotation." });
  }
});

app.put("/api/quotations/:id", auth, allow("photographer", "admin"), (req, res) => {
  try {
    const q = db.quotations.find(x => x.id === req.params.id);
    if (!q) return res.status(404).json({ error: "Quotation not found." });

    if (req.user.role === "photographer") {
      const photogUser = db.users.find(u => u.id === req.user.id);
      if (photogUser) {
        evalSubscription(photogUser);
        if (photogUser.subscriptionStatus === "expired") {
          return res.status(402).json({ error: "Subscription expired. Please renew to edit quotations." });
        }
      }
      if (!q.photographerId) q.photographerId = req.user.id;
      else if (q.photographerId !== req.user.id) {
        return res.status(403).json({ error: "Not allowed to edit another photographer's quotation." });
      }
    }

    const { studioName, showStudioInfo, packageName, packageDescription, showPackageDetails, servicesList, discount, advanceAmount, terms, contactPhone, contactEmail } = req.body || {};

    const photogUser = db.users.find(u => u.id === req.user.id);

    q.customization = {
      studioName: studioName || photogUser?.studioName || photogUser?.name || "Wedding Memories Studio",
      showStudioInfo: showStudioInfo !== false,
      packageName: packageName || "Premium Wedding Coverage",
      packageDescription: packageDescription || "Full day coverage capturing all precious moments.",
      showPackageDetails: showPackageDetails !== false,
      servicesList: Array.isArray(servicesList) ? servicesList : [],
      discount: Number(discount) || 0,
      advanceAmount: Number(advanceAmount) || 0,
      terms: terms || "1. 50% advance to confirm booking.\n2. Raw photos delivered within 48 hours.\n3. Final album & video delivered within 3 weeks.",
      contactPhone: contactPhone || photogUser?.mobile || "",
      contactEmail: contactEmail || req.user.email,
      updatedAt: new Date().toISOString()
    };

    write(db);
    res.json({ quotation: q, message: "Quotation updated successfully." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error updating quotation." });
  }
});

app.post("/api/quotations/:id/view", auth, (req, res) => {
  try {
    const q = db.quotations.find(x => x.id === req.params.id);
    if (!q) return res.status(404).json({ error: "Quotation not found." });
    if (req.user.role === "customer" && q.customerId !== req.user.id) return res.status(403).json({ error: "Not allowed." });
    q.viewedAt = new Date().toISOString(); write(db); res.json({ quotation: q });
  } catch (err) {
    res.status(500).json({ error: "Error marking quotation as viewed." });
  }
});

app.post("/api/weddings", auth, allow("admin", "photographer"), async (req, res) => {
  try {
    if (req.user.role === "photographer") {
      const photogUser = db.users.find(u => u.id === req.user.id);
      if (photogUser) {
        evalSubscription(photogUser);
        if (photogUser.subscriptionStatus === "expired") {
          return res.status(402).json({ error: "Subscription expired. Please renew to create new wedding galleries." });
        }
      }
    }

    const { title, eventDate, venue, description } = req.body || {};
    if (!title) return res.status(400).json({ error: "Wedding title is required." });
    const wedding = { id: crypto.randomUUID(), title, eventDate: eventDate || "", venue: venue || "", description: description || "", ownerId: req.user.id, createdAt: new Date().toISOString(), publicToken: crypto.randomBytes(18).toString("hex") };
    wedding.qrDataUrl = await QRCode.toDataURL(`${process.env.PUBLIC_BASE_URL || "http://localhost:5173"}/gallery/${wedding.publicToken}`);
    db.weddings.unshift(wedding); write(db); res.status(201).json({ wedding });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error creating wedding." });
  }
});

app.get("/api/weddings", auth, (req, res) => {
  try {
    const isAdmin = req.user.role === "owner" || req.user.role === "admin";
    const weddings = isAdmin ? db.weddings : db.weddings.filter(w => w.ownerId === req.user.id);
    res.json({ weddings: weddings.map(w => ({ ...w, photoCount: db.photos.filter(p => p.weddingId === w.id).length })) });
  } catch (err) {
    res.status(500).json({ error: "Error fetching weddings." });
  }
});

app.delete("/api/weddings/:id", auth, allow("admin", "photographer"), (req, res) => {
  try {
    const wIdx = db.weddings.findIndex(w => w.id === req.params.id);
    if (wIdx === -1) return res.status(404).json({ error: "Wedding gallery not found." });
    const wedding = db.weddings[wIdx];
    const isAdmin = req.user.role === "owner" || req.user.role === "admin";
    if (!isAdmin && wedding.ownerId !== req.user.id) return res.status(403).json({ error: "Not your gallery." });

    const galleryPhotos = db.photos.filter(p => p.weddingId === wedding.id);
    galleryPhotos.forEach(p => {
      if (p.filename) {
        const filepath = path.join(UPLOADS, p.filename);
        if (fs.existsSync(filepath)) {
          try { fs.unlinkSync(filepath); } catch {}
        }
      }
    });

    db.photos = db.photos.filter(p => p.weddingId !== wedding.id);
    db.scans = db.scans.filter(s => s.weddingId !== wedding.id);
    db.weddings.splice(wIdx, 1);
    write(db);
    res.json({ ok: true, message: "Wedding gallery deleted successfully." });
  } catch (err) {
    res.status(500).json({ error: "Error deleting wedding gallery." });
  }
});

app.get("/api/gallery/:token", async (req, res) => {
  try {
    const wedding = db.weddings.find(w => w.publicToken === req.params.token);
    if (!wedding) return res.status(404).json({ error: "Gallery not found." });
    db.scans.push({ id: crypto.randomUUID(), weddingId: wedding.id, at: new Date().toISOString() }); write(db);
    res.json({ wedding: { id: wedding.id, title: wedding.title, eventDate: wedding.eventDate, venue: wedding.venue }, photos: db.photos.filter(p => p.weddingId === wedding.id) });
  } catch (err) {
    res.status(500).json({ error: "Error loading gallery." });
  }
});

// Upload Wedding Event Photos
app.post("/api/weddings/:id/photos", auth, allow("admin", "photographer"), upload.array("photos", 30), (req, res) => {
  try {
    if (req.user.role === "photographer") {
      const photogUser = db.users.find(u => u.id === req.user.id);
      if (photogUser) {
        evalSubscription(photogUser);
        if (photogUser.subscriptionStatus === "expired") {
          return res.status(402).json({ error: "Subscription expired. Please renew to upload photos." });
        }
      }
    }

    const wedding = db.weddings.find(w => w.id === req.params.id);
    if (!wedding) return res.status(404).json({ error: "Wedding not found." });
    const isAdmin = req.user.role === "owner" || req.user.role === "admin";
    if (!isAdmin && wedding.ownerId !== req.user.id) return res.status(403).json({ error: "Not your gallery." });

    const added = (req.files || []).map(f => ({
      id: crypto.randomUUID(),
      weddingId: wedding.id,
      filename: f.filename,
      url: `/uploads/${f.filename}`,
      originalName: f.originalname,
      uploadedAt: new Date().toISOString()
    }));

    db.photos.push(...added);
    write(db);
    res.status(201).json({ photos: added, message: "Photos uploaded successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error uploading photos." });
  }
});

app.get("/api/stats", auth, allow("admin", "photographer"), (req, res) => {
  try {
    const isAdmin = req.user.role === "owner" || req.user.role === "admin";
    if (isAdmin) {
      const allPhotogs = db.users.filter(u => u.role === "photographer").map(safeUser);
      const photogsActive = allPhotogs.filter(p => p.subscriptionStatus === "active").length;
      const photogsExpiring = allPhotogs.filter(p => p.subscriptionStatus === "expiring_soon").length;
      const photogsExpired = allPhotogs.filter(p => p.subscriptionStatus === "expired" || p.isActive === false).length;
      const renewalsDue = allPhotogs.filter(p => p.daysLeft <= 7 || p.subscriptionStatus === "expired");

      res.json({
        customers: db.users.filter(u => u.role === "customer").length,
        photographersTotal: allPhotogs.length,
        photographersActive,
        photographersExpiringSoon: photogsExpiring,
        photographersExpired: photogsExpired,
        quotations: db.quotations.length,
        quotationViews: db.quotations.filter(q => q.viewedAt).length,
        weddings: db.weddings.length,
        qrScans: db.scans.length,
        photos: db.photos.length,
        renewalsDue: renewalsDue.map(p => ({
          id: p.id,
          name: p.name,
          studioName: p.studioName,
          mobile: p.mobile,
          expiryDate: p.subscriptionEndDate || "N/A",
          daysLeft: p.daysLeft || 0,
          status: p.subscriptionStatus || "active"
        }))
      });
    } else {
      const photographerWeddings = db.weddings.filter(w => w.ownerId === req.user.id);
      const ids = new Set(photographerWeddings.map(w => w.id));
      const myShowcaseCount = (db.showcasePhotos || []).filter(p => p.photographerId === req.user.id).length;

      res.json({
        myWeddings: photographerWeddings.length,
        myPhotos: db.photos.filter(p => ids.has(p.weddingId)).length,
        myPortfolioPhotos: myShowcaseCount,
        qrScans: db.scans.filter(s => ids.has(s.weddingId)).length,
        quotations: db.quotations.length
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message || "Error fetching stats." });
  }
});

const clientDist = path.resolve(__dirname, "../client/dist");
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get("*", (_req, res) => res.sendFile(path.join(clientDist, "index.html")));
}
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Wedding Memories API running at http://localhost:${PORT}`));
