import React, { useEffect, useState } from "react";
import { Camera, Heart, User, LogOut, LayoutDashboard, Image, QrCode, FileText, Plus, Upload, ArrowRight, Menu, X, CalendarDays, Users, Eye, Download, ShieldCheck, Trash2, Printer, Share2, CheckSquare, Square, Edit, Power, Settings, Clock, AlertTriangle, Lock, RefreshCw, CreditCard, Filter, Video, Car, Tv, Sparkles, BookOpen, Edit3, Sun, Moon, Star, PhoneCall, Mail, MapPin } from "lucide-react";

const getApiUrl = () => {
  if (typeof window !== "undefined" && window.location && window.location.hostname) {
    return `http://${window.location.hostname}:4000/api`;
  }
  return "http://localhost:4000/api";
};
const API = getApiUrl();
const img = "https://images.unsplash.com/photo-1519741497674-611481863552?w=1800";

const getImageUrl = (url) => {
  if (!url) return "";
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  return API.replace("/api", "") + url;
};

function normalizeRole(r) {
  if (r === "owner" || r === "admin") return "admin";
  return r || "";
}

const DEFAULT_SERVICES = [
  { name: "Traditional Wedding Photography", price: 15000, enabled: true },
  { name: "Cinematic Videography & Teaser", price: 25000, enabled: true },
  { name: "Pre-Wedding Couple Shoot", price: 15000, enabled: true },
  { name: "Car Opening & Grand Entry Video", price: 12000, enabled: true },
  { name: "Drone Aerial Shoot", price: 10000, enabled: true },
  { name: "Premium Hardcover Photo Album", price: 12000, enabled: true },
  { name: "Haldi, Sangeet & Pre-Shoot Coverage", price: 18000, enabled: true },
  { name: "Live Event Streaming (YouTube/LED)", price: 15000, enabled: false }
];

const DEFAULT_HOME_CONTENT = {
  heroEyebrow: "CAPTURING YOUR LOVE STORY",
  heroTitle: "Every Moment Deserves to be Remembered",
  heroSubtitle: "Capturing your beautiful stories, one frame at a time.",
  heroBgImage: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1800",
  heroButtonText1: "Explore Our Work",
  heroButtonText2: "Book Your Date",
  featureEyebrow: "OUR EXPERTISE",
  featureTitle: "Photography Services Made Timeless",
  card1Title: "Wedding Photography",
  card1Desc: "Honest emotional moments, candid portraits, and traditional ceremony rituals.",
  card2Title: "Cinematic Films",
  card2Desc: "4K movie-style wedding films, emotional teasers, and color-graded highlights.",
  card3Title: "QR Photo Gallery",
  card3Desc: "Scan, view, and download wedding photos instantly via private QR codes.",
  ctaEyebrow: "YOUR DAY, YOUR STORY",
  ctaTitle: "One beautiful day. A lifetime of memories.",
  ctaButtonText: "Book Your Date & Request Quotation"
};

function App() {
  const [token, setToken] = useState(() => localStorage.getItem("wm_token") || "");
  const [user, setUser] = useState(() => {
    try {
      const u = JSON.parse(localStorage.getItem("wm_user") || "null");
      const r = localStorage.getItem("wm_role");
      if (u) {
        u.role = normalizeRole(r || u.role);
      }
      return u;
    } catch {
      return null;
    }
  });

  const [theme, setTheme] = useState(() => localStorage.getItem("wm_theme") || "light");

  const [page, setPage] = useState(() => {
    if (location.pathname.startsWith("/gallery/")) return "publicGallery";
    const savedRole = localStorage.getItem("wm_role") || (user ? normalizeRole(user.role) : "");
    if (savedRole === "admin") return "adminDashboard";
    if (savedRole === "photographer") return "photographerDashboard";
    if (savedRole === "customer") return "customer";
    return "home";
  });

  const [notice, setNotice] = useState("");
  const [modal, setModal] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [data, setData] = useState({ stats: null, quotations: [], weddings: [], photographers: [], customers: [] });
  const [busy, setBusy] = useState(false);
  const [galleryToken, setGalleryToken] = useState(location.pathname.split("/gallery/")[1] || "");
  const [publicGallery, setPublic] = useState(null);

  // Home Page Editable Content State
  const [homeContent, setHomeContent] = useState(DEFAULT_HOME_CONTENT);

  // Photographer Sample Portfolio Showcase Photos State
  const [showcasePhotos, setShowcasePhotos] = useState([]);
  const [myShowcasePhotos, setMyShowcasePhotos] = useState([]);

  // Public Gallery Filters
  const [selectedStudioFilter, setSelectedStudioFilter] = useState("all");
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState("all");

  // Admin Dashboard Filter
  const [photogFilter, setPhotogFilter] = useState("all");

  // Public Photographers List for Client Quotation Request Form
  const [publicPhotographers, setPublicPhotographers] = useState([]);
  const [selectedPhotographerId, setSelectedPhotographerId] = useState("");
  const [selectedServicesList, setSelectedServicesList] = useState(["Traditional Wedding Photography"]);

  // Quotation Editor State
  const [activeQuote, setActiveQuote] = useState(null);
  const [editServices, setEditServices] = useState(DEFAULT_SERVICES);

  // Photographer Services Management State
  const [photogServicesConfig, setPhotogServicesConfig] = useState(DEFAULT_SERVICES);

  // Photographer Admin Management State
  const [selectedPhotographer, setSelectedPhotographer] = useState(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("wm_theme", theme);
  }, [theme]);

  function toggleTheme() {
    setTheme(prev => prev === "dark" ? "light" : "dark");
  }

  function logout() {
    setToken("");
    setUser(null);
    localStorage.removeItem("wm_token");
    localStorage.removeItem("wm_user");
    localStorage.removeItem("wm_role");
    setPage("home");
    setMobileNavOpen(false);
  }

  async function api(path, options = {}) {
    const headers = {
      ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers
    };
    try {
      const r = await fetch(API + path, { ...options, headers });
      const body = await r.json().catch(() => ({}));
      if (r.status === 401) {
        logout();
        throw new Error(body.error || "Session expired. Please log in again.");
      }
      if (!r.ok) {
        throw new Error(body.error || `Request failed (${r.status}). Please try again.`);
      }
      return body;
    } catch (err) {
      if (err.name === "TypeError" && err.message.includes("fetch")) {
        throw new Error("Unable to connect to server. Please check your network connection.");
      }
      throw err;
    }
  }

  function login(result) {
    const role = normalizeRole(result.user.role);
    const userObj = { ...result.user, role };
    setToken(result.token);
    setUser(userObj);
    localStorage.setItem("wm_token", result.token);
    localStorage.setItem("wm_user", JSON.stringify(userObj));
    localStorage.setItem("wm_role", role);
    setNotice(`Logged in successfully as ${role.toUpperCase()}.`);
    setModal("");

    if (role === "admin") setPage("adminDashboard");
    else if (role === "photographer") setPage("photographerDashboard");
    else if (role === "customer") setPage("customer");
    else setPage("home");
  }

  async function refreshUserData() {
    if (!token) return;
    try {
      const res = await api("/me");
      if (res.user) {
        const role = normalizeRole(res.user.role);
        const userObj = { ...res.user, role };
        setUser(userObj);
        localStorage.setItem("wm_user", JSON.stringify(userObj));
        setNotice("Account status refreshed.");
      }
    } catch (e) {
      setNotice(e.message);
    }
  }

  // Fetch Home Page Content on load
  useEffect(() => {
    fetch(`${API}/public/home-content`)
      .then(r => r.json())
      .then(data => {
        if (data.content) {
          setHomeContent(prev => ({ ...prev, ...data.content }));
        }
      })
      .catch(() => {});
  }, []);

  async function loadDashboard() {
    if (!token || !user) return;
    const role = normalizeRole(user.role);
    try {
      if (role === "customer") {
        const q = await api("/quotations").catch(() => ({ quotations: [] }));
        setData({ quotations: q.quotations || [], weddings: [], stats: {}, photographers: [], customers: [] });
      } else if (role === "admin") {
        const [q, w, s, p, c] = await Promise.all([
          api("/quotations").catch(() => ({ quotations: [] })),
          api("/weddings").catch(() => ({ weddings: [] })),
          api("/stats").catch(() => ({})),
          api("/photographers").catch(() => ({ photographers: [] })),
          api("/customers").catch(() => ({ customers: [] }))
        ]);
        setData({
          quotations: q.quotations || [],
          weddings: w.weddings || [],
          stats: s || {},
          photographers: p.photographers || [],
          customers: c.customers || []
        });
      } else if (role === "photographer") {
        const [q, w, s, me, myShowcase] = await Promise.all([
          api("/quotations").catch(() => ({ quotations: [] })),
          api("/weddings").catch(() => ({ weddings: [] })),
          api("/stats").catch(() => ({})),
          api("/me").catch(() => null),
          api("/photographers/my-showcase-photos").catch(() => ({ photos: [] }))
        ]);
        if (me?.user) {
          const userObj = { ...me.user, role: "photographer" };
          setUser(userObj);
          localStorage.setItem("wm_user", JSON.stringify(userObj));
        }
        setMyShowcasePhotos(myShowcase?.photos || []);
        setData({ quotations: q.quotations || [], weddings: w.weddings || [], stats: s || {}, photographers: [], customers: [] });
        setPhotogServicesConfig(user.servicesList && user.servicesList.length ? user.servicesList : DEFAULT_SERVICES);
      }
    } catch (e) {
      if (e.message && !e.message.includes("Session expired")) {
        setNotice(e.message);
      }
    }
  }

  useEffect(() => {
    if (token && user) loadDashboard();
  }, [token, user?.role, page]);

  useEffect(() => {
    if (page === "publicGallery" && galleryToken) {
      fetch(`${API}/gallery/${galleryToken}`)
        .then(r => r.json())
        .then(setPublic)
        .catch(() => {});
    }
  }, [page, galleryToken]);

  // Load public showcase portfolio photos when Gallery page is opened
  useEffect(() => {
    if (page === "gallery" || page === "home") {
      fetch(`${API}/public/showcase-photos`)
        .then(r => r.json())
        .then(data => setShowcasePhotos(data.photos || []))
        .catch(() => {});
      fetch(`${API}/public/photographers`)
        .then(r => r.json())
        .then(data => setPublicPhotographers(data.photographers || []))
        .catch(() => {});
    }
  }, [page]);

  // Load public active photographers list when client opens quotation modal
  useEffect(() => {
    if (modal === "quote") {
      fetch(`${API}/public/photographers`)
        .then(r => r.json())
        .then(data => {
          setPublicPhotographers(data.photographers || []);
          if (data.photographers && data.photographers.length > 0 && !selectedPhotographerId) {
            setSelectedPhotographerId(data.photographers[0].id);
          }
        })
        .catch(() => {});
    }
  }, [modal]);

  // Screen role protection checks
  useEffect(() => {
    const role = user ? normalizeRole(user.role) : "";
    if (page === "adminDashboard") {
      if (!token || !user || role !== "admin") {
        setNotice("Access denied. Admin login required.");
        setPage("home");
        setModal("login");
      }
    } else if (page === "photographerDashboard") {
      if (!token || !user || role !== "photographer") {
        setNotice("Access denied. Photographer login required.");
        setPage("home");
        setModal("login");
      }
    } else if (page === "customer") {
      if (!token || !user || role !== "customer") {
        setNotice("Access denied. Customer login required.");
        setPage("home");
        setModal("login");
      }
    }
  }, [page, user, token]);

  async function submitAuth(e, mode) {
    e.preventDefault();
    setBusy(true);
    const f = new FormData(e.currentTarget);
    const body = Object.fromEntries(f.entries());
    try {
      const r = await fetch(`${API}/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Incorrect login details.");
      if (mode === "login") {
        login(j);
      }
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function updateProfile(e) {
    e.preventDefault();
    setBusy(true);
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    try {
      const res = await api("/profile", { method: "PUT", body: JSON.stringify(f) });
      const role = normalizeRole(res.user.role);
      const userObj = { ...res.user, role };
      setUser(userObj);
      setToken(res.token);
      localStorage.setItem("wm_token", res.token);
      localStorage.setItem("wm_user", JSON.stringify(userObj));
      localStorage.setItem("wm_role", role);
      setNotice("Profile updated successfully!");
      setModal("");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function uploadLogo(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("logo", file);
    try {
      setBusy(true);
      const res = await api("/photographers/logo", { method: "POST", body: form });
      const userObj = { ...user, logoUrl: res.logoUrl };
      setUser(userObj);
      localStorage.setItem("wm_user", JSON.stringify(userObj));
      setNotice("Business logo updated successfully!");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Admin Save Home Page Content & Hero Banner Photo
  async function saveHomeContent(e) {
    e.preventDefault();
    setBusy(true);
    const form = new FormData(e.currentTarget);
    try {
      const res = await api("/admin/home-content", { method: "PUT", body: form });
      setHomeContent(res.content);
      setNotice("Home page banner photo & content updated successfully!");
      setModal("");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Photographer Save Offered Services Configuration
  async function savePhotogServicesConfig(e) {
    e.preventDefault();
    try {
      setBusy(true);
      const res = await api("/photographers/services", {
        method: "PUT",
        body: JSON.stringify({ servicesList: photogServicesConfig })
      });
      const userObj = { ...user, servicesList: res.user.servicesList };
      setUser(userObj);
      localStorage.setItem("wm_user", JSON.stringify(userObj));
      setNotice("Your offered services and rates updated successfully!");
      setModal("");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  function togglePhotogConfigService(index) {
    setPhotogServicesConfig(prev => prev.map((s, i) => i === index ? { ...s, enabled: !s.enabled } : s));
  }

  function updatePhotogConfigPrice(index, price) {
    setPhotogServicesConfig(prev => prev.map((s, i) => i === index ? { ...s, price: Number(price) || 0 } : s));
  }

  function addCustomPhotogConfigService() {
    const name = window.prompt("Enter new service name (e.g. Car Opening Video, Drone Shoot, Live Streaming):");
    if (!name || !name.trim()) return;
    const priceStr = window.prompt("Enter price in Rupees (₹):", "10000");
    const price = Number(priceStr) || 0;
    setPhotogServicesConfig(prev => [...prev, { name: name.trim(), price, enabled: true }]);
  }

  // Upload Photographer Sample Portfolio Photos
  async function uploadPortfolioPhotos(e) {
    e.preventDefault();
    setBusy(true);
    const form = new FormData(e.currentTarget);
    try {
      const res = await api("/photographers/showcase-photos", { method: "POST", body: form });
      setNotice(res.message);
      setModal("");
      loadDashboard();
      if (page === "gallery" || page === "home") {
        fetch(`${API}/public/showcase-photos`)
          .then(r => r.json())
          .then(d => setShowcasePhotos(d.photos || []));
      }
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Delete Photographer Sample Portfolio Photo
  async function deleteShowcasePhoto(id) {
    if (!window.confirm("Are you sure you want to delete this sample portfolio photo?")) return;
    try {
      await api(`/photographers/showcase-photos/${id}`, { method: "DELETE" });
      setNotice("Sample photo deleted successfully.");
      setMyShowcasePhotos(prev => prev.filter(p => p.id !== id));
      if (page === "gallery" || page === "home") {
        setShowcasePhotos(prev => prev.filter(p => p.id !== id));
      }
    } catch (err) {
      setNotice(err.message);
    }
  }

  // Client Submit Quotation Request
  async function createQuote(e) {
    e.preventDefault();
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const body = {
      customerName: form.get("customerName"),
      phone: form.get("phone"),
      email: form.get("email"),
      eventDate: form.get("eventDate"),
      venue: form.get("venue"),
      notes: form.get("notes"),
      photographerId: selectedPhotographerId,
      selectedServices: selectedServicesList
    };

    try {
      const res = await fetch(`${API}/quotations`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(body)
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to submit request.");
      setNotice("Quotation request submitted successfully!");
      setModal("");
      if (token && user) loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  function toggleClientSelectedService(serviceName) {
    setSelectedServicesList(prev =>
      prev.includes(serviceName)
        ? prev.filter(s => s !== serviceName)
        : [...prev, serviceName]
    );
  }

  // Admin Add Photographer handler
  async function saveNewPhotographer(e) {
    e.preventDefault();
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const name = form.get("name")?.toString().trim();
    const mobile = form.get("mobile")?.toString().trim();
    const emailStr = form.get("email")?.toString().trim();
    const password = form.get("password")?.toString();

    if (!name) { setNotice("Full name is required."); setBusy(false); return; }
    if (!mobile || !/^\d{10}$/.test(mobile)) { setNotice("Mobile number must be exactly 10 digits."); setBusy(false); return; }
    if (!emailStr || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailStr)) { setNotice("A valid email address is required."); setBusy(false); return; }
    if (!password || password.length < 6) { setNotice("Password must be at least 6 characters."); setBusy(false); return; }

    try {
      await api("/photographers", { method: "POST", body: form });
      setNotice("Photographer account created with 30-day active subscription.");
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Admin Renew Photographer Subscription
  async function saveSubscriptionRenewal(e) {
    e.preventDefault();
    if (!selectedPhotographer) return;
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const body = {
      amount: Number(form.get("amount")) || 999,
      paymentMode: form.get("paymentMode"),
      notes: form.get("notes")
    };

    try {
      const res = await api(`/photographers/${selectedPhotographer.id}/renew`, {
        method: "POST",
        body: JSON.stringify(body)
      });
      setNotice(res.message);
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Admin Add Client / Customer handler
  async function saveNewCustomer(e) {
    e.preventDefault();
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const name = form.get("name")?.toString().trim();
    const emailStr = form.get("email")?.toString().trim();
    const password = form.get("password")?.toString();

    if (!name) { setNotice("Full name is required."); setBusy(false); return; }
    if (!emailStr || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailStr)) { setNotice("A valid email address is required."); setBusy(false); return; }
    if (!password || password.length < 6) { setNotice("Password must be at least 6 characters."); setBusy(false); return; }

    try {
      await api("/customers", { method: "POST", body: form });
      setNotice("Client account created successfully.");
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Admin Edit Photographer handler
  async function saveEditPhotographer(e) {
    e.preventDefault();
    if (!selectedPhotographer) return;
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const mobile = form.get("mobile")?.toString().trim();
    const emailStr = form.get("email")?.toString().trim();

    if (mobile && !/^\d{10}$/.test(mobile)) { setNotice("Mobile number must be exactly 10 digits."); setBusy(false); return; }
    if (emailStr && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailStr)) { setNotice("A valid email address is required."); setBusy(false); return; }

    try {
      await api(`/photographers/${selectedPhotographer.id}`, { method: "PUT", body: form });
      setNotice("Photographer profile updated successfully.");
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  // Admin Toggle Active/Deactivate Photographer Status
  async function togglePhotographerStatus(id) {
    try {
      const res = await api(`/photographers/${id}/toggle-active`, { method: "PATCH" });
      setNotice(res.message);
      if (selectedPhotographer?.id === id) {
        setSelectedPhotographer(prev => prev ? { ...prev, isActive: !prev.isActive } : null);
      }
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  // Admin Toggle Active/Deactivate Client Status
  async function toggleCustomerStatus(id) {
    try {
      const res = await api(`/customers/${id}/toggle-active`, { method: "PATCH" });
      setNotice(res.message);
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  function openEditQuoteModal(q) {
    setActiveQuote(q);
    const savedList = q.customization?.servicesList;
    if (savedList && savedList.length) {
      setEditServices(savedList);
    } else {
      setEditServices(user?.servicesList || DEFAULT_SERVICES);
    }
    setModal("editQuote");
  }

  function openPreviewQuoteModal(q) {
    setActiveQuote(q);
    setModal("previewQuote");
  }

  async function saveQuotation(e) {
    e.preventDefault();
    if (!activeQuote) return;
    setBusy(true);
    const form = new FormData(e.currentTarget);
    const body = {
      studioName: form.get("studioName"),
      contactPhone: form.get("contactPhone"),
      contactEmail: form.get("contactEmail"),
      packageName: form.get("packageName"),
      packageDescription: form.get("packageDescription"),
      discount: Number(form.get("discount")) || 0,
      advanceAmount: Number(form.get("advanceAmount")) || 0,
      terms: form.get("terms"),
      servicesList: editServices
    };

    try {
      const res = await api(`/quotations/${activeQuote.id}`, {
        method: "PUT",
        body: JSON.stringify(body)
      });
      setNotice("Quotation updated & saved successfully!");
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  function toggleService(index) {
    setEditServices(prev => prev.map((s, i) => i === index ? { ...s, enabled: !s.enabled } : s));
  }

  function updateServicePrice(index, price) {
    setEditServices(prev => prev.map((s, i) => i === index ? { ...s, price: Number(price) || 0 } : s));
  }

  async function createWedding(e) {
    e.preventDefault();
    setBusy(true);
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    try {
      await api("/weddings", { method: "POST", body: JSON.stringify(f) });
      setNotice("Wedding gallery created with QR code.");
      setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function uploadPhotos(e, weddingId) {
    const form = new FormData();
    [...e.target.files].forEach(f => form.append("photos", f));
    try {
      await api(`/weddings/${weddingId}/photos`, { method: "POST", body: form });
      setNotice("Photos uploaded successfully to wedding gallery.");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  async function deleteCustomer(id) {
    if (!window.confirm("Are you sure you want to delete this client account and all their requested quotations?")) return;
    try {
      await api(`/customers/${id}`, { method: "DELETE" });
      setNotice("Client deleted successfully.");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  async function deleteQuotation(id) {
    if (!window.confirm("Are you sure you want to delete this quotation request?")) return;
    try {
      await api(`/quotations/${id}`, { method: "DELETE" });
      setNotice("Quotation deleted successfully.");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  async function deletePhotographer(id) {
    if (!window.confirm("Are you sure you want to delete this photographer account?")) return;
    try {
      await api(`/photographers/${id}`, { method: "DELETE" });
      setNotice("Photographer deleted successfully.");
      if (modal === "viewPhotographer") setModal("");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  async function deleteWedding(id) {
    if (!window.confirm("Are you sure you want to delete this wedding gallery? All associated photos will be removed.")) return;
    try {
      await api(`/weddings/${id}`, { method: "DELETE" });
      setNotice("Wedding gallery deleted successfully.");
      loadDashboard();
    } catch (err) {
      setNotice(err.message);
    }
  }

  async function viewQuote(id) {
    try {
      await api(`/quotations/${id}/view`, { method: "POST" });
      loadDashboard();
    } catch (e) {
      setNotice(e.message);
    }
  }

  function go(p) {
    setPage(p);
    setNotice("");
    setMobileNavOpen(false);
    window.scrollTo(0, 0);
  }

  function galleryUrl(w) {
    return `${location.origin}/gallery/${w.publicToken}`;
  }

  function copy(text) {
    navigator.clipboard?.writeText(text);
    setNotice("Gallery link copied to clipboard.");
  }

  function shareWhatsApp(q) {
    const cust = q.customization || {};
    const servicesText = (cust.servicesList || DEFAULT_SERVICES)
      .filter(s => s.enabled)
      .map(s => `• ${s.name}: ₹${s.price}`)
      .join("%0A");

    const subtotal = (cust.servicesList || DEFAULT_SERVICES).filter(s => s.enabled).reduce((sum, s) => sum + (s.price || 0), 0);
    const total = Math.max(0, subtotal - (cust.discount || 0));
    const balance = Math.max(0, total - (cust.advanceAmount || 0));

    const msg = `*WEDDING PHOTOGRAPHY QUOTATION*%0A%0A` +
      `*Studio:* ${cust.studioName || user?.studioName || user?.name || "Wedding Memories"}%0A` +
      `*Client:* ${q.customerName}%0A` +
      `*Date:* ${q.eventDate} | *Venue:* ${q.venue}%0A%0A` +
      `*Services Included:*%0A${servicesText}%0A%0A` +
      `*Total Package:* ₹${total}%0A` +
      `*Advance Paid:* ₹${cust.advanceAmount || 0}%0A` +
      `*Balance Due:* ₹${balance}%0A%0A` +
      `Thank you for choosing us!`;

    window.open(`https://api.whatsapp.com/send?text=${msg}`, "_blank");
  }

  if (page === "publicGallery") {
    return (
      <div className="public-gallery">
        <header>
          <Brand onClick={() => go("home")} />
        </header>
        {publicGallery?.wedding ? (
          <>
            <p className="eyebrow">A PRIVATE WEDDING GALLERY</p>
            <h1>{publicGallery.wedding.title}</h1>
            <p>{publicGallery.wedding.eventDate} · {publicGallery.wedding.venue}</p>
            <div className="public-photos">
              {publicGallery.photos?.map(p => (
                <a key={p.id} href={getImageUrl(p.url)} download>
                  <img src={getImageUrl(p.url)} alt="Wedding photo" />
                  <span><Download size={16} /> Download</span>
                </a>
              ))}
            </div>
          </>
        ) : (
          <h2>Loading gallery…</h2>
        )}
      </div>
    );
  }

  const role = user ? normalizeRole(user.role) : "";
  const selectedPhotogObj = publicPhotographers.find(p => p.id === selectedPhotographerId);
  const availableServicesForClient = selectedPhotogObj?.servicesList && selectedPhotogObj.servicesList.length ? selectedPhotogObj.servicesList : DEFAULT_SERVICES;

  // Filter Photographers for Admin Dashboard
  const filteredPhotographers = (data.photographers || []).filter(p => {
    if (!p) return false;
    const status = p.subscriptionStatus || "active";
    if (photogFilter === "active") return status === "active";
    if (photogFilter === "expiring_soon") return status === "expiring_soon";
    if (photogFilter === "expired") return status === "expired" || p.isActive === false;
    return true;
  });

  // Filter Public Showcase Portfolio Photos
  const filteredShowcasePhotos = showcasePhotos.filter(p => {
    if (!p) return false;
    if (selectedStudioFilter !== "all" && p.photographerId !== selectedStudioFilter) return false;
    if (selectedCategoryFilter !== "all" && String(p.category || "").toLowerCase() !== selectedCategoryFilter.toLowerCase()) return false;
    return true;
  });

  const heroBg = getImageUrl(homeContent.heroBgImage) || img;

  const heroOverlay = theme === "dark"
    ? `linear-gradient(90deg, rgba(11,11,11,0.92), rgba(11,11,11,0.55))`
    : `linear-gradient(90deg, rgba(248,243,234,0.92), rgba(248,243,234,0.60))`;

  return (
    <div className="app">
      <header className="nav">
        <Brand onClick={() => go("home")} />

        {/* Desktop Navigation Links */}
        <nav>
          <a onClick={() => go("home")}>Home</a>
          <a onClick={() => go("services")}>Services</a>
          <a onClick={() => go("gallery")}>Portfolio</a>
          {user && role === "admin" && (
            <a onClick={() => go("adminDashboard")}>Admin Dashboard</a>
          )}
          {user && role === "photographer" && (
            <a onClick={() => go("photographerDashboard")}>Photographer Workspace</a>
          )}
          {user && role === "customer" && (
            <a onClick={() => go("customer")}>My Space</a>
          )}
        </nav>

        <div className="nav-right">
          {/* Dark / Ivory Theme Toggle Button */}
          <button
            className="btn ghost small theme-toggle-btn"
            onClick={toggleTheme}
            title={`Switch to ${theme === "dark" ? "Ivory Light" : "Dark Gold"} Mode`}
          >
            {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
            <span>{theme === "dark" ? "Ivory Mode" : "Dark Mode"}</span>
          </button>

          {user ? (
            <>
              <span className="user-chip" onClick={() => setModal("profile")} title="Edit Profile" style={{ cursor: "pointer" }}>
                {user.name} · {role.toUpperCase()}
              </span>
              <button className="btn ghost small" onClick={() => setModal("profile")}>
                <User size={14} /> Profile
              </button>
              <button className="btn ghost small" onClick={logout}>
                <LogOut size={15} /> Logout
              </button>
            </>
          ) : (
            <button className="btn gold small" onClick={() => setModal("login")}>Login</button>
          )}

          {/* Mobile Menu Toggle Button */}
          <button className="mobile-menu-toggle" onClick={() => setMobileNavOpen(!mobileNavOpen)} aria-label="Toggle navigation menu">
            {mobileNavOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileNavOpen && (
        <div className="mobile-nav-drawer">
          <a onClick={() => go("home")}>🏠 Home</a>
          <a onClick={() => go("services")}>🎬 Services & Pricing</a>
          <a onClick={() => go("gallery")}>📸 Portfolio Showcase</a>
          {user && role === "admin" && (
            <a onClick={() => go("adminDashboard")}>👑 Admin Dashboard</a>
          )}
          {user && role === "photographer" && (
            <a onClick={() => go("photographerDashboard")}>📷 Photographer Workspace</a>
          )}
          <a onClick={toggleTheme}>
            {theme === "dark" ? "☀️ Switch to Ivory Light Mode" : "🌙 Switch to Dark Mode"}
          </a>
          {user ? (
            <a onClick={logout} style={{ color: "#ff8888" }}>🚪 Logout ({user.name})</a>
          ) : (
            <a onClick={() => { setModal("login"); setMobileNavOpen(false); }}>🔑 Login</a>
          )}
        </div>
      )}

      {notice && (
        <div className="notice" onClick={() => setNotice("")}>
          {notice} <X size={14} />
        </div>
      )}

      {/* DEDICATED SERVICES SHOWCASE PAGE */}
      {page === "services" && (
        <section className="section" style={{ padding: "60px 8%", minHeight: "80vh" }}>
          <p className="eyebrow">WHAT WE OFFER & PRICING</p>
          <h1 style={{ font: "500 44px 'Playfair Display',serif", margin: "10px 0 20px" }}>Professional Photography & Film Services</h1>
          <p style={{ color: "var(--text-muted)", maxWidth: "650px", lineHeight: "1.7", marginBottom: "35px" }}>
            Explore our wide range of photography, videography, grand entry videos, drone shoots, and album printing options tailored to capture every precious moment of your wedding.
          </p>

          <div className="cards" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
            <article>
              <Camera size={32} />
              <h3>Traditional Wedding Photography</h3>
              <p>Comprehensive full-day coverage capturing classic family portraits, rituals, and timeless moments in high definition.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹15,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Traditional Wedding Photography"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <Video size={32} />
              <h3>Cinematic Videography & Teaser</h3>
              <p>4K 60fps movie-style cinematic wedding film, emotional teaser highlights, and professional color-graded video edits.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹25,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Cinematic Videography & Teaser"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <Heart size={32} />
              <h3>Pre-Wedding Couple Shoot</h3>
              <p>Romantic scenic outdoor couple shoot with multiple dress changes, cinematic slow-motion clips, and portrait reels.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹15,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Pre-Wedding Couple Shoot"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <Car size={32} />
              <h3>Car Opening & Grand Entry Video</h3>
              <p>Exclusive cinematic coverage of bride & groom car opening, vintage car entry, cold pyro sparklers, and royal arrival video.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹12,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Car Opening & Grand Entry Video"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <Sparkles size={32} />
              <h3>Drone Aerial Shoot</h3>
              <p>High-altitude 4K aerial drone coverage of venue decor, royal bride-groom entry, baraat procession, and grand venue views.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹10,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Drone Aerial Shoot"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <BookOpen size={32} />
              <h3>Premium Hardcover Photo Album</h3>
              <p>High gloss non-tearable luxury wedding album with acrylic cover, velvet presentation briefcase, and custom design layouts.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹12,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Premium Hardcover Photo Album"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <CalendarDays size={32} />
              <h3>Haldi, Sangeet & Pre-Shoot Coverage</h3>
              <p>Vibrant coverage of Haldi ceremony, Mehendi, Sangeet dance performances, and family fun moments with custom reel edits.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹18,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Haldi, Sangeet & Pre-Shoot Coverage"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>

            <article>
              <Tv size={32} />
              <h3>Live Event Streaming (YouTube/LED)</h3>
              <p>Multi-camera live YouTube streaming and venue LED screen setup so distant relatives can watch your wedding live anywhere.</p>
              <b style={{ display: "block", color: "var(--color-primary)", fontSize: "17px", margin: "15px 0", fontFamily: "'Playfair Display', serif" }}>Starting at ₹15,000</b>
              <button className="btn gold small" style={{ width: "100%" }} onClick={() => { setSelectedServicesList(["Live Event Streaming (YouTube/LED)"]); setModal("quote"); }}>
                Book Service / Get Quotation
              </button>
            </article>
          </div>
        </section>
      )}

      {/* PUBLIC SHOWCASE PORTFOLIO GALLERY PAGE */}
      {page === "gallery" && (
        <section className="showcase-gallery-section">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "15px" }}>
            <div>
              <p className="eyebrow">PHOTOGRAPHER PORTFOLIO & WORK SHOWCASE</p>
              <h1 style={{ font: "500 42px 'Playfair Display',serif", margin: "8px 0" }}>Sample Photography Gallery</h1>
              <p style={{ color: "var(--text-muted)", margin: 0, fontSize: "14px" }}>
                Browse sample photography work uploaded by our partner studios to evaluate their style and quality before booking!
              </p>
            </div>
            {user && role === "photographer" && user?.subscriptionStatus !== "expired" && (
              <button className="btn gold" onClick={() => setModal("uploadPortfolio")}>
                <Plus size={16} /> Upload Sample Photos
              </button>
            )}
          </div>

          {/* Filter Bar for Public Gallery */}
          <div style={{ display: "flex", gap: "12px", marginTop: "24px", flexWrap: "wrap", alignItems: "center", background: "var(--bg-card)", padding: "14px 20px", border: "1px solid var(--border-color)", borderRadius: "10px" }}>
            <span style={{ fontSize: "13px", color: "var(--color-primary)", fontWeight: "bold", display: "flex", alignItems: "center", gap: "6px" }}>
              <Filter size={14} /> Filter Portfolio:
            </span>

            <select
              value={selectedStudioFilter}
              onChange={e => setSelectedStudioFilter(e.target.value)}
              style={{ background: "var(--input-bg)", color: "var(--input-text)", border: "1px solid var(--input-border)", padding: "8px 14px", borderRadius: "6px", fontSize: "13px" }}
            >
              <option value="all">All Photographer Studios</option>
              {publicPhotographers.map(p => (
                <option key={p.id} value={p.id}>{p.studioName || p.name}</option>
              ))}
            </select>

            <select
              value={selectedCategoryFilter}
              onChange={e => setSelectedCategoryFilter(e.target.value)}
              style={{ background: "var(--input-bg)", color: "var(--input-text)", border: "1px solid var(--input-border)", padding: "8px 14px", borderRadius: "6px", fontSize: "13px" }}
            >
              <option value="all">All Categories</option>
              <option value="Wedding">Wedding Photography</option>
              <option value="Pre-Wedding">Pre-Wedding Couple Shoot</option>
              <option value="Cinematic">Cinematic Highlights</option>
              <option value="Car Opening">Car Opening & Grand Entry Video</option>
              <option value="Traditional">Traditional Rituals</option>
              <option value="Drone">Drone Aerial Shots</option>
            </select>

            <button className="btn ghost small" onClick={() => { setSelectedStudioFilter("all"); setSelectedCategoryFilter("all"); }}>
              Reset Filters
            </button>
          </div>

          {filteredShowcasePhotos.length ? (
            <div className="showcase-gallery-grid">
              {filteredShowcasePhotos.map(p => (
                <article className="showcase-card" key={p.id}>
                  <img src={getImageUrl(p.url)} alt={p.title} />
                  <div className="showcase-info">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                      <span className="showcase-category-tag">{p.category || "Wedding"}</span>
                      {user && (role === "admin" || (role === "photographer" && user.id === p.photographerId)) && (
                        <button className="btn ghost small danger" style={{ padding: "3px 6px" }} onClick={() => deleteShowcasePhoto(p.id)} title="Delete Photo">
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                    <h3>{p.title || "Sample Portfolio Shot"}</h3>

                    <div className="showcase-studio-badge">
                      {p.photographerLogo ? (
                        <img src={getImageUrl(p.photographerLogo)} alt="Logo" className="showcase-studio-logo" />
                      ) : (
                        <div className="showcase-studio-logo" style={{ display: "grid", placeItems: "center", color: "#111", fontWeight: "bold" }}>📸</div>
                      )}
                      <span className="showcase-studio-text">{p.photographerStudio || p.photographerName}</span>
                    </div>

                    <div className="showcase-actions">
                      <button
                        className="btn gold small"
                        style={{ width: "100%" }}
                        onClick={() => {
                          setSelectedPhotographerId(p.photographerId);
                          setModal("quote");
                        }}
                      >
                        Request Quotation from this Studio
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "60px 0", color: "var(--text-muted)" }}>
              <Camera size={48} style={{ opacity: 0.5, marginBottom: "12px" }} />
              <h3>No sample portfolio photos match your filters</h3>
              <p>Photographers can upload their best sample shots to show clients here!</p>
            </div>
          )}
        </section>
      )}

      {/* PUBLIC HOME PAGE */}
      {page === "home" && (
        <>
          {/* HERO BANNER SECTION */}
          <section className="hero" style={{ backgroundImage: `${heroOverlay},url(${heroBg})` }}>
            <div className="hero-copy">
              <p className="eyebrow"><Sparkle /> {homeContent.heroEyebrow || "CAPTURING YOUR LOVE STORY"}</p>
              <h1>
                {homeContent.heroTitle ? homeContent.heroTitle : "Every Moment Deserves to be Remembered"}
              </h1>
              <p>{homeContent.heroSubtitle || "Capturing your beautiful stories, one frame at a time."}</p>
              <div className="actions">
                <button className="btn gold" onClick={() => go("gallery")}>
                  {homeContent.heroButtonText1 || "Explore Our Work"} <ArrowRight size={16} />
                </button>
                <button className="btn ghost" onClick={() => setModal("quote")}>
                  {homeContent.heroButtonText2 || "Book Your Date"}
                </button>
                {user && role === "admin" && (
                  <button className="btn gold" style={{ background: "var(--color-primary)", color: "var(--bg-primary)" }} onClick={() => setModal("editHomeContent")}>
                    <Edit3 size={16} /> Edit Home Screen Banner & Content
                  </button>
                )}
              </div>
            </div>
          </section>

          {/* ABOUT SECTION */}
          <section className="section split" style={{ background: "var(--bg-primary)", borderBottom: "1px solid var(--border-color)" }}>
            <div>
              <p className="eyebrow">ABOUT WEDDING MEMORIES</p>
              <h2>Crafting Timeless <em>Visual Elegance</em></h2>
              <p style={{ color: "var(--text-muted)", maxWidth: "600px", lineHeight: "1.8", marginTop: "16px", fontSize: "15px" }}>
                Wedding Memories is a premier luxury wedding photography & cinematography platform connecting discerning couples with world-class wedding photographers. We capture unscripted emotions, candid smiles, grand arrivals, and sacred rituals in high definition.
              </p>
            </div>
            <div style={{ display: "grid", gap: "15px" }}>
              <div className="stat" style={{ minWidth: "240px" }}>
                <span>Verified Photographers</span>
                <b>5+ Studios</b>
              </div>
              <div className="stat">
                <span>QR Private Galleries</span>
                <b>Instant Scan</b>
              </div>
            </div>
          </section>

          {/* SERVICES SECTION */}
          <section className="section">
            <p className="eyebrow">{homeContent.featureEyebrow || "OUR EXPERTISE"}</p>
            <h2>{homeContent.featureTitle || "Photography Services Made Timeless"}</h2>
            <div className="cards">
              <article>
                <Camera size={32} />
                <h3>{homeContent.card1Title || "Wedding Photography"}</h3>
                <p>{homeContent.card1Desc || "Honest emotional moments, candid portraits, and traditional ceremony rituals."}</p>
              </article>
              <article>
                <Video size={32} />
                <h3>{homeContent.card2Title || "Cinematic Films"}</h3>
                <p>{homeContent.card2Desc || "4K movie-style wedding films, emotional teasers, and color-graded highlights."}</p>
              </article>
              <article>
                <QrCode size={32} />
                <h3>{homeContent.card3Title || "QR Photo Gallery"}</h3>
                <p>{homeContent.card3Desc || "Scan, view, and download wedding photos instantly via private QR codes."}</p>
              </article>
            </div>
            <div style={{ textAlign: "center", marginTop: "35px" }}>
              <button className="btn gold" onClick={() => go("services")}>
                View All Services & Pricing <ArrowRight size={16} />
              </button>
            </div>
          </section>

          {/* FEATURED PORTFOLIO PREVIEW */}
          {showcasePhotos.length > 0 && (
            <section className="section" style={{ background: "var(--bg-primary)" }}>
              <p className="eyebrow">FEATURED PORTFOLIO</p>
              <h2>Recent <em>Wedding Stories</em></h2>
              <div className="showcase-gallery-grid">
                {showcasePhotos.slice(0, 3).map(p => (
                  <article className="showcase-card" key={p.id}>
                    <img src={getImageUrl(p.url)} alt={p.title} />
                    <div className="showcase-info">
                      <span className="showcase-category-tag">{p.category}</span>
                      <h3 style={{ marginTop: "8px" }}>{p.title}</h3>
                      <div className="showcase-studio-badge">
                        <span className="showcase-studio-text">{p.photographerStudio || p.photographerName}</span>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
              <div style={{ textAlign: "center", marginTop: "35px" }}>
                <button className="btn ghost" onClick={() => go("gallery")}>
                  Explore Full Portfolio <ArrowRight size={16} />
                </button>
              </div>
            </section>
          )}

          {/* TESTIMONIALS SECTION */}
          <section className="section" style={{ background: "var(--bg-secondary)" }}>
            <p className="eyebrow">HAPPY COUPLES</p>
            <h2>Words from <em>Our Couples</em></h2>
            <div className="testimonial-grid">
              <div className="testimonial-card">
                <div style={{ color: "#D5B477", fontSize: "16px", marginBottom: "8px" }}>⭐⭐⭐⭐⭐</div>
                <p>"Wedding Memories made our special day unforgettable! The QR code photo sharing was a huge hit with all our wedding guests."</p>
                <div className="testimonial-author">Aarav & Anaya Patil</div>
                <div className="testimonial-city">Mumbai Wedding</div>
              </div>

              <div className="testimonial-card">
                <div style={{ color: "#D5B477", fontSize: "16px", marginBottom: "8px" }}>⭐⭐⭐⭐⭐</div>
                <p>"The cinematic videography and pre-wedding couple shoot exceeded all our expectations. High quality albums delivered right on time!"</p>
                <div className="testimonial-author">Rahul & Priya Shewale</div>
                <div className="testimonial-city">Pune Wedding</div>
              </div>

              <div className="testimonial-card">
                <div style={{ color: "#D5B477", fontSize: "16px", marginBottom: "8px" }}>⭐⭐⭐⭐⭐</div>
                <p>"Super convenient quotation system and very transparent pricing. Their team captured every sacred ritual with pure elegance."</p>
                <div className="testimonial-author">Rohan & Sneha Kulkarni</div>
                <div className="testimonial-city">Nashik Wedding</div>
              </div>
            </div>
          </section>

          {/* CALL TO ACTION SECTION */}
          <section className="section split" style={{ background: "var(--bg-card)", borderTop: "1px solid var(--border-color)" }}>
            <div>
              <p className="eyebrow">{homeContent.ctaEyebrow || "YOUR DAY, YOUR STORY"}</p>
              <h2>{homeContent.ctaTitle || "One beautiful day. A lifetime of memories."}</h2>
            </div>
            <button className="btn gold" onClick={() => setModal("quote")}>
              {homeContent.ctaButtonText || "Book Your Date & Request Quotation"} <ArrowRight size={16} />
            </button>
          </section>
        </>
      )}

      {/* Customer Space Screen */}
      {page === "customer" && role === "customer" && (
        <section className="dashboard">
          <p className="eyebrow">CUSTOMER SPACE</p>
          <h1>Welcome, {user?.name}</h1>
          <button className="btn gold" onClick={() => setModal("quote")}>
            <Plus /> Request a quotation
          </button>
          <h2>Your quotations</h2>
          <QuoteList items={data.quotations} onView={viewQuote} onDelete={deleteQuotation} />
        </section>
      )}

      {/* ADMIN DASHBOARD SCREEN */}
      {page === "adminDashboard" && role === "admin" && (
        <section className="dashboard">
          <p className="eyebrow">ADMIN CONTROL CENTER</p>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
            <h1 style={{ margin: 0 }}>Admin Dashboard</h1>
            <button className="btn gold" onClick={() => setModal("editHomeContent")}>
              <Edit3 size={16} /> Edit Home Page Banner & Content
            </button>
          </div>

          {/* Subscription Overview Cards */}
          <div className="stats">
            <div className="stat">
              <span>Total Photographers</span>
              <b>{data.stats?.photographersTotal || data.photographers?.length || 0}</b>
            </div>
            <div className="stat">
              <span>Active Subscriptions</span>
              <b style={{ color: "#2E6930" }}>{data.stats?.photographersActive || data.photographers?.filter(p => p.subscriptionStatus === "active").length || 0}</b>
            </div>
            <div className="stat">
              <span>Expiring Soon (≤ 5 Days)</span>
              <b style={{ color: "#856404" }}>{data.stats?.photographersExpiringSoon || data.photographers?.filter(p => p.subscriptionStatus === "expiring_soon").length || 0}</b>
            </div>
            <div className="stat">
              <span>Expired / Suspended</span>
              <b style={{ color: "#721C24" }}>{data.stats?.photographersExpired || data.photographers?.filter(p => p.subscriptionStatus === "expired" || p.isActive === false).length || 0}</b>
            </div>
          </div>

          {/* Renewals Due This Week Alert Box */}
          {data.stats?.renewalsDue && data.stats.renewalsDue.length > 0 && (
            <div className="subscription-warning-banner">
              <div>
                <b style={{ color: "#856404", display: "flex", alignItems: "center", gap: "6px" }}>
                  <AlertTriangle size={18} /> Renewals Due This Week ({data.stats.renewalsDue.length})
                </b>
                <div style={{ fontSize: "12px", marginTop: "4px" }}>
                  The following photographers need subscription renewal soon or are expired:
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginTop: "8px" }}>
                    {data.stats.renewalsDue.map(p => (
                      <span key={p.id} style={{ background: "var(--bg-card-inner)", padding: "4px 8px", borderRadius: "4px", border: "1px solid var(--border-color)" }}>
                        {p.name} ({p.studioName || "Studio"}) - Expiry: <b>{p.expiryDate}</b> ({p.daysLeft <= 0 ? "EXPIRED" : `${p.daysLeft} days left`})
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="dash-head">
            <h2>Manage Photographers & Subscriptions</h2>
            <button className="btn gold" onClick={() => setModal("addPhotographer")}>
              <Plus size={16} /> Add Photographer
            </button>
          </div>

          {/* Photographers Subscription Filter Tabs */}
          <div className="filter-tabs">
            <button className={`filter-tab ${photogFilter === "all" ? "active" : ""}`} onClick={() => setPhotogFilter("all")}>
              All ({data.photographers?.length || 0})
            </button>
            <button className={`filter-tab ${photogFilter === "active" ? "active" : ""}`} onClick={() => setPhotogFilter("active")}>
              Active ({data.photographers?.filter(p => p.subscriptionStatus === "active").length || 0})
            </button>
            <button className={`filter-tab ${photogFilter === "expiring_soon" ? "active" : ""}`} onClick={() => setPhotogFilter("expiring_soon")}>
              Expiring Soon ({data.photographers?.filter(p => p.subscriptionStatus === "expiring_soon").length || 0})
            </button>
            <button className={`filter-tab ${photogFilter === "expired" ? "active" : ""}`} onClick={() => setPhotogFilter("expired")}>
              Expired ({data.photographers?.filter(p => p.subscriptionStatus === "expired" || p.isActive === false).length || 0})
            </button>
          </div>

          <div className="photographers-list">
            {filteredPhotographers.length ? (
              filteredPhotographers.map(p => (
                <article className="photographer-card" key={p.id}>
                  <div className="photographer-info-cell">
                    {p.profilePhoto ? (
                      <img src={getImageUrl(p.profilePhoto)} alt={p.name} className="photographer-avatar" />
                    ) : (
                      <div className="photographer-avatar"><Camera size={20} /></div>
                    )}
                    <div>
                      <b>
                        {p.name}
                        {p.studioName && <span style={{ color: "var(--color-secondary)", fontSize: "14px", fontWeight: "normal" }}> ({p.studioName})</span>}

                        {/* Subscription Status Badges */}
                        {p.subscriptionStatus === "active" && (
                          <span className="status-badge active">
                            ACTIVE ({p.daysLeft} DAYS LEFT)
                          </span>
                        )}
                        {p.subscriptionStatus === "expiring_soon" && (
                          <span className="status-badge expiring">
                            EXPIRING IN {p.daysLeft} DAYS
                          </span>
                        )}
                        {(p.subscriptionStatus === "expired" || p.isActive === false) && (
                          <span className="status-badge expired">
                            EXPIRED / DEACTIVATED
                          </span>
                        )}
                      </b>
                      <p>Expiry Date: <b>{p.subscriptionEndDate || "N/A"}</b> · {p.email} · {p.mobile || "No phone"}</p>
                    </div>
                  </div>
                  <div className="photographer-actions">
                    <button className="btn gold small" onClick={() => { setSelectedPhotographer(p); setModal("renewSubscription"); }}>
                      <Clock size={14} /> Renew
                    </button>
                    <button className="btn ghost small" onClick={() => { setSelectedPhotographer(p); setModal("viewPhotographer"); }}>
                      <Eye size={14} /> Details
                    </button>
                    <button className="btn ghost small" onClick={() => { setSelectedPhotographer(p); setModal("editPhotographer"); }}>
                      <Edit size={14} /> Edit
                    </button>
                    <button className="btn ghost small danger" onClick={() => deletePhotographer(p.id)}>
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </article>
              ))
            ) : (
              <p className="muted">No photographers found in this category.</p>
            )}
          </div>

          <div className="dash-head" style={{ marginTop: "30px" }}>
            <h2>Registered Clients / Customers</h2>
            <button className="btn gold" onClick={() => setModal("addCustomer")}>
              <Plus size={16} /> Add Client
            </button>
          </div>

          <div className="photographers-list">
            {data.customers?.length ? (
              data.customers.map(c => (
                <article className="photographer-card" key={c.id}>
                  <div className="photographer-info-cell">
                    <div className="photographer-avatar"><User size={20} /></div>
                    <div>
                      <b>
                        {c.name}
                        <span className={`status-badge ${c.isActive !== false ? "active" : "deactivated"}`}>
                          {c.isActive !== false ? "ACTIVE" : "DISABLED"}
                        </span>
                      </b>
                      <p>{c.email} {c.mobile ? `· ${c.mobile}` : ""}</p>
                    </div>
                  </div>
                  <div className="photographer-actions">
                    <button className="btn ghost small" onClick={() => toggleCustomerStatus(c.id)}>
                      <Power size={14} /> {c.isActive !== false ? "Disable Login" : "Enable Login"}
                    </button>
                    <button className="btn ghost small danger" onClick={() => deleteCustomer(c.id)}>
                      <Trash2 size={14} /> Delete Client
                    </button>
                  </div>
                </article>
              ))
            ) : (
              <p className="muted">No clients registered yet. Click "Add Client" to create one.</p>
            )}
          </div>

          <h2>All Customer Quotations</h2>
          <QuoteList items={data.quotations} onView={viewQuote} onDelete={deleteQuotation} />

          <h2>All Registered Wedding Galleries</h2>
          <div className="wedding-list">
            {data.weddings.length ? data.weddings.map(w => (
              <article className="wedding" key={w.id}>
                <div>
                  <h3>{w.title}</h3>
                  <p>{w.eventDate} · {w.venue} · {w.photoCount} photos</p>
                  <button className="link-button" onClick={() => copy(galleryUrl(w))}>
                    Copy gallery link
                  </button>
                </div>
                <div className="qr">
                  <img src={w.qrDataUrl} alt="Wedding gallery QR code" />
                  <a href={w.qrDataUrl} download={`${w.title}-QR.png`}>Download QR</a>
                </div>
                <div className="wedding-actions">
                  <button className="btn ghost small danger" onClick={() => deleteWedding(w.id)}>
                    <Trash2 size={14} /> Delete gallery
                  </button>
                </div>
              </article>
            )) : <p className="muted">No wedding galleries created yet.</p>}
          </div>
        </section>
      )}

      {/* PHOTOGRAPHER DASHBOARD SCREEN */}
      {page === "photographerDashboard" && role === "photographer" && (
        <section className="dashboard">
          <p className="eyebrow">PHOTOGRAPHER WORKSPACE</p>

          {/* EXPIRED SUBSCRIPTION BLOCK SCREEN */}
          {user?.subscriptionStatus === "expired" ? (
            <div className="subscription-expired-screen">
              <Lock size={48} color="#721C24" />
              <h2>Subscription Expired</h2>
              <p>
                Your monthly subscription expired on <b>{user.subscriptionEndDate || "recently"}</b>.<br />
                Please renew your subscription to access your workspace, manage wedding galleries, and edit quotations.
              </p>
              <div style={{ display: "flex", justifyContent: "center", gap: "12px", flexWrap: "wrap" }}>
                <button className="btn gold" onClick={() => setModal("contactAdmin")}>
                  <CreditCard size={16} /> Contact Admin to Renew
                </button>
                <button className="btn ghost" onClick={refreshUserData}>
                  <RefreshCw size={16} /> Refresh Status
                </button>
                <button className="btn ghost danger" onClick={logout}>
                  <LogOut size={16} /> Logout
                </button>
              </div>
            </div>
          ) : (
            <>
              <h1>Welcome, {user?.studioName || user?.name}</h1>

              {/* Expiring Soon Warning Banner */}
              {user?.daysLeft <= 5 && (
                <div className="subscription-warning-banner">
                  <div>
                    <b style={{ color: "#856404", display: "flex", alignItems: "center", gap: "6px" }}>
                      <AlertTriangle size={18} /> Subscription Expiring Soon
                    </b>
                    <p style={{ margin: "4px 0 0", fontSize: "13px" }}>
                      Your monthly subscription expires in <b>{user.daysLeft} days</b> (on {user.subscriptionEndDate}). Please renew to avoid service interruption.
                    </p>
                  </div>
                  <button className="btn gold small" onClick={() => setModal("contactAdmin")}>
                    <Clock size={14} /> Renew Subscription
                  </button>
                </div>
              )}

              {/* Subscription Status Card */}
              <div className="photographer-profile-box" style={{ display: "block" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
                  <div>
                    <span className="eyebrow">MEMBERSHIP PLAN</span>
                    <h3 style={{ margin: "4px 0 0", font: "500 22px 'Playfair Display',serif" }}>Monthly Photographer Plan (₹{user?.amount || 999}/month)</h3>
                    <p style={{ margin: "4px 0 0", color: "var(--text-muted)", fontSize: "13px" }}>
                      Valid until: <b>{user?.subscriptionEndDate}</b> · Days Remaining: <b style={{ color: user?.daysLeft <= 5 ? "#856404" : "#2E6930" }}>{user?.daysLeft} days</b>
                    </p>
                  </div>
                  <button className="btn gold small" onClick={() => setModal("contactAdmin")}>
                    <CreditCard size={14} /> Renew / Pay
                  </button>
                </div>
              </div>

              {/* Photographer Sample Portfolio Showcase Section */}
              <div className="photographer-profile-box" style={{ display: "block" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                  <div>
                    <h3 style={{ margin: 0, font: "500 22px 'Playfair Display',serif" }}>Public Sample Portfolio Photos</h3>
                    <p style={{ margin: "4px 0 0", color: "var(--text-muted)", fontSize: "13px" }}>
                      Upload your best sample photos (Pre-wedding, Cinematic portraits, Drone shots). Clients see these on the public Gallery page to evaluate your work before requesting a quotation!
                    </p>
                  </div>
                  <button className="btn gold small" onClick={() => setModal("uploadPortfolio")}>
                    <Plus size={14} /> Upload Sample Photos
                  </button>
                </div>

                {myShowcasePhotos.length ? (
                  <div className="my-portfolio-grid">
                    {myShowcasePhotos.map(p => (
                      <div className="my-portfolio-item" key={p.id}>
                        <img src={getImageUrl(p.url)} alt={p.title} />
                        <div className="my-portfolio-item-body">
                          <h4>{p.title}</h4>
                          <p>{p.category} · {p.uploadedAt ? new Date(p.uploadedAt).toLocaleDateString() : ""}</p>
                          <button
                            className="btn ghost small danger"
                            style={{ marginTop: "6px", width: "100%", padding: "4px" }}
                            onClick={() => deleteShowcasePhoto(p.id)}
                          >
                            <Trash2 size={12} /> Delete Photo
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="muted" style={{ margin: "10px 0 0", fontSize: "13px" }}>
                    You haven't uploaded any sample portfolio photos yet. Click "+ Upload Sample Photos" to show clients your best work!
                  </p>
                )}
              </div>

              {/* Business Logo Section */}
              <div className="photographer-profile-box">
                <div className="logo-preview-container">
                  {user?.logoUrl ? (
                    <img src={getImageUrl(user.logoUrl)} alt="Business Logo" className="photographer-logo-img" />
                  ) : (
                    <div className="logo-placeholder">
                      <Camera size={26} />
                      <span>No Logo</span>
                    </div>
                  )}
                </div>
                <div className="logo-details">
                  <h3>{user?.studioName || "Business Logo"}</h3>
                  <p>Upload your studio logo. It will automatically appear on all quotations and shared PDFs.</p>
                  <label className="btn gold small upload">
                    <Upload size={14} /> {user?.logoUrl ? "Change Logo" : "Upload Logo"}
                    <input type="file" accept="image/*" onChange={uploadLogo} />
                  </label>
                </div>
              </div>

              {/* Photographer Offered Services & Rates Setup */}
              <div className="photographer-profile-box" style={{ display: "block" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                  <div>
                    <h3 style={{ margin: 0, font: "500 22px 'Playfair Display',serif" }}>Offered Services & Pricing (₹)</h3>
                    <p style={{ margin: "4px 0 0", color: "var(--text-muted)", fontSize: "13px" }}>
                      Configure what services you offer and set your default prices in Rupees (₹). Clients can select from these when requesting a quotation!
                    </p>
                  </div>
                  <button className="btn gold small" onClick={() => setModal("configureServices")}>
                    <Settings size={14} /> Configure Services
                  </button>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginTop: "10px" }}>
                  {(user?.servicesList || DEFAULT_SERVICES).map((srv, i) => (
                    <span key={i} style={{ background: "var(--bg-card-inner)", border: "1px solid var(--border-color)", color: srv.enabled ? "var(--color-primary)" : "var(--text-muted)", padding: "6px 12px", borderRadius: "20px", fontSize: "13px", fontWeight: "500" }}>
                      {srv.name} · ₹{srv.price} {srv.enabled ? "" : "(Disabled)"}
                    </span>
                  ))}
                </div>
              </div>

              <div className="stats">
                {Object.entries(data.stats || {}).map(([k, v]) => (
                  <div className="stat" key={k}>
                    <span>{k.replace(/[A-Z]/g, " $&")}</span>
                    <b>{v}</b>
                  </div>
                ))}
              </div>

              <div className="dash-head">
                <h2>My Wedding Galleries (QR Private Galleries)</h2>
                <button className="btn gold" onClick={() => setModal("wedding")}>
                  <Plus size={16} /> New wedding
                </button>
              </div>

              <div className="wedding-list">
                {data.weddings.length ? data.weddings.map(w => (
                  <article className="wedding" key={w.id}>
                    <div>
                      <h3>{w.title}</h3>
                      <p>{w.eventDate} · {w.venue} · {w.photoCount} photos</p>
                      <button className="link-button" onClick={() => copy(galleryUrl(w))}>
                        Copy gallery link
                      </button>
                    </div>
                    <div className="qr">
                      <img src={w.qrDataUrl} alt="Wedding gallery QR code" />
                      <a href={w.qrDataUrl} download={`${w.title}-QR.png`}>Download QR</a>
                    </div>
                    <div className="wedding-actions">
                      <label className="upload btn ghost">
                        <Upload size={15} /> Upload photos
                        <input type="file" accept="image/*" multiple onChange={e => uploadPhotos(e, w.id)} />
                      </label>
                      <button className="btn ghost small danger" onClick={() => deleteWedding(w.id)}>
                        <Trash2 size={14} /> Delete gallery
                      </button>
                    </div>
                  </article>
                )) : <p className="muted">No wedding galleries created yet.</p>}
              </div>

              <h2>Customer Quotations</h2>
              <QuoteList
                items={data.quotations}
                onView={viewQuote}
                isPhotographer={true}
                onEdit={openEditQuoteModal}
                onPreview={openPreviewQuoteModal}
                onDelete={deleteQuotation}
              />
            </>
          )}
        </section>
      )}

      <footer>
        <Brand onClick={() => go("home")} />
        <p>Capturing your beautiful stories, one frame at a time.</p>
        <small>© 2026 Wedding Memories. All Rights Reserved.</small>
      </footer>

      {modal && (
        <div className="overlay" onClick={() => setModal("")}>
          <div className={`modal ${modal === "editQuote" || modal === "previewQuote" || modal === "addPhotographer" || modal === "editPhotographer" || modal === "viewPhotographer" || modal === "configureServices" || modal === "addCustomer" || modal === "renewSubscription" || modal === "uploadPortfolio" || modal === "editHomeContent" ? "wide" : ""}`} onClick={e => e.stopPropagation()}>
            <button className="close" onClick={() => setModal("")}><X /></button>

            {modal === "login" && (
              <>
                <p className="eyebrow">WELCOME BACK</p>
                <h2>Login</h2>
                <form onSubmit={e => submitAuth(e, "login")}>
                  <label>Email or 10-digit Mobile
                    <input name="email" required placeholder="email@example.com or 9876543210" />
                  </label>
                  <label>Password
                    <input name="password" type="password" required />
                  </label>
                  <button className="btn gold" disabled={busy}>Login</button>
                </form>
              </>
            )}

            {/* ADMIN EDIT HOME PAGE CONTENT & BANNER PHOTO MODAL */}
            {modal === "editHomeContent" && role === "admin" && (
              <>
                <p className="eyebrow">ADMIN WEBSITE CMS</p>
                <h2>Edit Home Page Banner & Content</h2>
                <form onSubmit={saveHomeContent}>
                  <div style={{ background: "var(--bg-card-inner)", padding: "16px", border: "1px solid var(--border-color)", borderRadius: "8px", marginBottom: "15px" }}>
                    <p className="eyebrow" style={{ marginTop: 0 }}>HOME SCREEN BANNER PHOTO</p>
                    <div style={{ display: "flex", gap: "15px", alignItems: "center", flexWrap: "wrap" }}>
                      <img
                        src={heroBg}
                        alt="Current Home Banner"
                        style={{ width: "120px", height: "70px", objectFit: "cover", borderRadius: "6px", border: "1px solid var(--color-primary)" }}
                      />
                      <div style={{ flex: 1, minWidth: "200px" }}>
                        <label style={{ margin: 0 }}>Upload New Banner Photo File
                          <input name="heroBgImage" type="file" accept="image/*" />
                        </label>
                        <span style={{ fontSize: "11px", color: "var(--text-muted)", marginTop: "4px", display: "block" }}>
                          Or enter Direct Image URL:
                        </span>
                        <input name="heroBgImageUrl" placeholder="https://images.unsplash.com/..." defaultValue={homeContent.heroBgImage?.startsWith("http") ? homeContent.heroBgImage : ""} style={{ marginTop: "4px" }} />
                      </div>
                    </div>
                  </div>

                  <p className="eyebrow" style={{ marginTop: "6px" }}>HERO TEXT & BUTTONS</p>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Hero Eyebrow Text
                      <input name="heroEyebrow" defaultValue={homeContent.heroEyebrow} />
                    </label>
                    <label>Hero Main Title
                      <input name="heroTitle" defaultValue={homeContent.heroTitle} required />
                    </label>
                  </div>

                  <label>Hero Subtitle / Description
                    <textarea name="heroSubtitle" defaultValue={homeContent.heroSubtitle} />
                  </label>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Button 1 Text
                      <input name="heroButtonText1" defaultValue={homeContent.heroButtonText1} />
                    </label>
                    <label>Button 2 Text
                      <input name="heroButtonText2" defaultValue={homeContent.heroButtonText2} />
                    </label>
                  </div>

                  <p className="eyebrow" style={{ marginTop: "14px" }}>FEATURES / SERVICES SECTION</p>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Section Eyebrow
                      <input name="featureEyebrow" defaultValue={homeContent.featureEyebrow} />
                    </label>
                    <label>Section Title
                      <input name="featureTitle" defaultValue={homeContent.featureTitle} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Card 1 Title
                      <input name="card1Title" defaultValue={homeContent.card1Title} />
                    </label>
                    <label>Card 1 Description
                      <input name="card1Desc" defaultValue={homeContent.card1Desc} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Card 2 Title
                      <input name="card2Title" defaultValue={homeContent.card2Title} />
                    </label>
                    <label>Card 2 Description
                      <input name="card2Desc" defaultValue={homeContent.card2Desc} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Card 3 Title
                      <input name="card3Title" defaultValue={homeContent.card3Title} />
                    </label>
                    <label>Card 3 Description
                      <input name="card3Desc" defaultValue={homeContent.card3Desc} />
                    </label>
                  </div>

                  <p className="eyebrow" style={{ marginTop: "14px" }}>BOTTOM CALL-TO-ACTION (CTA) SECTION</p>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>CTA Eyebrow
                      <input name="ctaEyebrow" defaultValue={homeContent.ctaEyebrow} />
                    </label>
                    <label>CTA Button Text
                      <input name="ctaButtonText" defaultValue={homeContent.ctaButtonText} />
                    </label>
                  </div>

                  <label>CTA Heading
                    <input name="ctaTitle" defaultValue={homeContent.ctaTitle} />
                  </label>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "12px" }}>
                    Save & Update Home Page Photo & Text
                  </button>
                </form>
              </>
            )}

            {/* PHOTOGRAPHER UPLOAD SAMPLE PORTFOLIO PHOTOS MODAL */}
            {modal === "uploadPortfolio" && (
              <>
                <p className="eyebrow">PORTFOLIO SHOWCASE</p>
                <h2>Upload Sample Work / Portfolio Photos</h2>
                <p style={{ color: "var(--text-muted)", fontSize: "13px", marginBottom: "15px" }}>
                  Upload high-quality sample photos of your work. Clients visit the public Gallery page to inspect sample photos before requesting quotations!
                </p>

                <form onSubmit={uploadPortfolioPhotos}>
                  <label>Photo Title / Caption *
                    <input name="title" required placeholder="e.g. Pre-Wedding Couple Sunset Portrait" />
                  </label>

                  <label>Category *
                    <select name="category" defaultValue="Wedding">
                      <option value="Wedding">Wedding Photography</option>
                      <option value="Pre-Wedding">Pre-Wedding Shoot</option>
                      <option value="Cinematic">Cinematic Highlights</option>
                      <option value="Car Opening">Car Opening & Grand Entry Video</option>
                      <option value="Traditional">Traditional Rituals</option>
                      <option value="Drone">Drone Aerial Shots</option>
                    </select>
                  </label>

                  <label>Select Sample Image Files (Up to 10 photos) *
                    <input name="photos" type="file" accept="image/*" multiple required />
                  </label>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "10px" }}>
                    Upload to Public Gallery
                  </button>
                </form>
              </>
            )}

            {/* CONTACT ADMIN FOR RENEWAL MODAL */}
            {modal === "contactAdmin" && (
              <>
                <p className="eyebrow">SUBSCRIPTION RENEWAL</p>
                <h2>Renew Photographer Subscription</h2>
                <div style={{ background: "var(--bg-card-inner)", padding: "22px", border: "1px solid var(--border-color)", borderRadius: "10px", fontSize: "14px", lineHeight: "1.8" }}>
                  <p style={{ marginTop: 0 }}>To renew your monthly plan or extend your subscription validity, please contact the Admin:</p>
                  <div><b>Admin Name:</b> Bhavesh Shewale</div>
                  <div><b>Mobile / Phone:</b> +91 9322467921 / +91 9876543210</div>
                  <div><b>Email:</b> bhaveshshewale76@gmail.com</div>
                  <div><b>Monthly Plan Amount:</b> ₹{user?.amount || 999} / month</div>
                  <div><b>Accepted Payment Modes:</b> Cash / UPI (GPay, PhonePe, Paytm)</div>
                  <p style={{ color: "var(--color-primary)", marginBottom: 0, marginTop: "12px", fontWeight: "600" }}>
                    * Once Admin receives payment, your subscription will be instantly renewed for 30 days.
                  </p>
                </div>
                <div style={{ display: "flex", gap: "10px", marginTop: "18px" }}>
                  <button className="btn gold" onClick={refreshUserData}>
                    <RefreshCw size={15} /> Check / Refresh Status
                  </button>
                  <button className="btn ghost" onClick={() => setModal("")}>Close</button>
                </div>
              </>
            )}

            {/* ADMIN RENEW SUBSCRIPTION MODAL */}
            {modal === "renewSubscription" && selectedPhotographer && (
              <>
                <p className="eyebrow">ADMIN SUBSCRIPTION RENEWAL</p>
                <h2>Renew Subscription for {selectedPhotographer.name}</h2>
                <p style={{ color: "var(--text-muted)", fontSize: "13px" }}>
                  Current Expiry Date: <b>{selectedPhotographer.subscriptionEndDate || "Expired"}</b>
                </p>

                <form onSubmit={saveSubscriptionRenewal}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Renewal Amount (₹) *
                      <input name="amount" type="number" defaultValue={selectedPhotographer.amount || 999} required />
                    </label>
                    <label>Payment Mode *
                      <select name="paymentMode" defaultValue="UPI">
                        <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
                        <option value="Cash">Cash</option>
                        <option value="Online">Online Bank Transfer</option>
                      </select>
                    </label>
                  </div>

                  <label>Transaction Reference / Notes
                    <input name="notes" placeholder="Txn ID / Payment reference" />
                  </label>

                  <p style={{ fontSize: "13px", color: "#2E6930", marginTop: "8px", fontWeight: "500" }}>
                    * This will extend the validity by <b>30 days</b> and immediately set status to ACTIVE.
                  </p>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "10px" }}>
                    Confirm & Extend Validity (+30 Days)
                  </button>
                </form>
              </>
            )}

            {/* ADD CLIENT / CUSTOMER MODAL (Admin Only) */}
            {modal === "addCustomer" && (
              <>
                <p className="eyebrow">ADMIN CONTROL</p>
                <h2>Add New Client Account</h2>
                <form onSubmit={saveNewCustomer}>
                  <label>Full Name *
                    <input name="name" required placeholder="Client Full Name" />
                  </label>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Email Address (used for login) *
                      <input name="email" type="email" required placeholder="client@example.com" />
                    </label>
                    <label>Mobile Number
                      <input name="mobile" placeholder="9876543210" maxLength="10" />
                    </label>
                  </div>
                  <label>Login Password *
                    <input name="password" type="password" minLength="6" required placeholder="••••••••" />
                  </label>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "10px" }}>
                    Create Client Account
                  </button>
                </form>
              </>
            )}

            {/* PHOTOGRAPHER CONFIGURE OFFERED SERVICES MODAL */}
            {modal === "configureServices" && (
              <>
                <p className="eyebrow">PHOTOGRAPHER SETTINGS</p>
                <h2>Configure Offered Services & Rates (₹)</h2>
                <form onSubmit={savePhotogServicesConfig}>
                  <p style={{ color: "var(--text-muted)", fontSize: "13px", marginBottom: "15px" }}>
                    Enable the services you offer and set default prices in Rupees (₹).
                  </p>

                  <div className="services-editor-list">
                    {photogServicesConfig.map((srv, idx) => (
                      <div className="service-edit-item" key={idx}>
                        <label>
                          <input type="checkbox" checked={srv.enabled} onChange={() => togglePhotogConfigService(idx)} />
                          <span>{srv.name}</span>
                        </label>
                        <input
                          type="number"
                          value={srv.price}
                          onChange={e => updatePhotogConfigPrice(idx, e.target.value)}
                          placeholder="Price (₹)"
                          disabled={!srv.enabled}
                        />
                      </div>
                    ))}
                  </div>

                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "16px" }}>
                    <button type="button" className="btn ghost small" onClick={addCustomPhotogConfigService}>
                      <Plus size={14} /> Add Custom Service
                    </button>
                    <button className="btn gold" disabled={busy}>Save Services & Rates</button>
                  </div>
                </form>
              </>
            )}

            {/* ADD PHOTOGRAPHER MODAL (Admin Only) */}
            {modal === "addPhotographer" && (
              <>
                <p className="eyebrow">ADMIN CONTROL</p>
                <h2>Add New Photographer</h2>
                <form onSubmit={saveNewPhotographer}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Full Name *
                      <input name="name" required placeholder="John Doe" />
                    </label>
                    <label>Studio / Business Name
                      <input name="studioName" placeholder="Royal Wedding Studios" />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Mobile Number (10 digits) *
                      <input name="mobile" required placeholder="9876543210" maxLength="10" />
                    </label>
                    <label>Email Address (used for login) *
                      <input name="email" type="email" required placeholder="photographer@studio.com" />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Login Password *
                      <input name="password" type="password" minLength="6" required placeholder="••••••••" />
                    </label>
                    <label>City
                      <input name="city" placeholder="Mumbai, Delhi, etc." />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Subscription Start Date
                      <input name="subscriptionStartDate" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                    </label>
                    <label>Plan Amount (₹)
                      <input name="amount" type="number" defaultValue={999} />
                    </label>
                  </div>

                  <label>Address
                    <input name="address" placeholder="123 Studio Street, Main Area" />
                  </label>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Experience / Specialization
                      <input name="experience" placeholder="Wedding, Pre-wedding, Cinematic" />
                    </label>
                    <label>Joining Date
                      <input name="joiningDate" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Profile Photo (Optional)
                      <input name="profilePhoto" type="file" accept="image/*" />
                    </label>
                    <label>Studio Logo (Optional)
                      <input name="logo" type="file" accept="image/*" />
                    </label>
                  </div>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "10px" }}>
                    Save & Create Account
                  </button>
                </form>
              </>
            )}

            {/* EDIT PHOTOGRAPHER MODAL (Admin Only) */}
            {modal === "editPhotographer" && selectedPhotographer && (
              <>
                <p className="eyebrow">ADMIN CONTROL</p>
                <h2>Edit Photographer: {selectedPhotographer.name}</h2>
                <form onSubmit={saveEditPhotographer}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Full Name *
                      <input name="name" defaultValue={selectedPhotographer.name} required />
                    </label>
                    <label>Studio / Business Name
                      <input name="studioName" defaultValue={selectedPhotographer.studioName} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Mobile Number (10 digits) *
                      <input name="mobile" defaultValue={selectedPhotographer.mobile} required maxLength="10" />
                    </label>
                    <label>Email Address *
                      <input name="email" type="email" defaultValue={selectedPhotographer.email} required />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>New Password (leave blank to keep current)
                      <input name="password" type="password" minLength="6" placeholder="••••••••" />
                    </label>
                    <label>City
                      <input name="city" defaultValue={selectedPhotographer.city} />
                    </label>
                  </div>

                  <label>Address
                    <input name="address" defaultValue={selectedPhotographer.address} />
                  </label>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Experience / Specialization
                      <input name="experience" defaultValue={selectedPhotographer.experience} />
                    </label>
                    <label>Joining Date
                      <input name="joiningDate" type="date" defaultValue={selectedPhotographer.joiningDate} />
                    </label>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Update Profile Photo (Optional)
                      <input name="profilePhoto" type="file" accept="image/*" />
                    </label>
                    <label>Update Studio Logo (Optional)
                      <input name="logo" type="file" accept="image/*" />
                    </label>
                  </div>

                  <button className="btn gold" disabled={busy} style={{ marginTop: "10px" }}>
                    Save Changes
                  </button>
                </form>
              </>
            )}

            {/* VIEW PHOTOGRAPHER DETAILS & PAYMENT HISTORY MODAL */}
            {modal === "viewPhotographer" && selectedPhotographer && (
              <>
                <p className="eyebrow">PHOTOGRAPHER DETAILS & SUBSCRIPTION</p>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <h2>{selectedPhotographer.name}</h2>
                  <span className={`status-badge ${selectedPhotographer.subscriptionStatus === "active" ? "active" : selectedPhotographer.subscriptionStatus === "expiring_soon" ? "expiring" : "expired"}`}>
                    {selectedPhotographer.subscriptionStatus === "active" ? `ACTIVE (${selectedPhotographer.daysLeft} DAYS LEFT)` : selectedPhotographer.subscriptionStatus === "expiring_soon" ? `EXPIRING (${selectedPhotographer.daysLeft} DAYS LEFT)` : "EXPIRED"}
                  </span>
                </div>

                <div className="photographer-details-grid">
                  <div><b>STUDIO NAME</b>{selectedPhotographer.studioName || "N/A"}</div>
                  <div><b>MOBILE NUMBER</b>{selectedPhotographer.mobile || "N/A"}</div>
                  <div><b>EMAIL ADDRESS</b>{selectedPhotographer.email}</div>
                  <div><b>CITY</b>{selectedPhotographer.city || "N/A"}</div>
                  <div><b>SUBSCRIPTION PLAN</b>Monthly Plan (₹{selectedPhotographer.amount || 999}/month)</div>
                  <div><b>EXPIRY DATE</b>{selectedPhotographer.subscriptionEndDate || "N/A"}</div>
                  <div><b>DAYS REMAINING</b>{selectedPhotographer.daysLeft || 0} days</div>
                  <div><b>ACCOUNT STATUS</b>{selectedPhotographer.isActive ? "Enabled" : "Deactivated"}</div>
                </div>

                <p className="eyebrow" style={{ marginTop: "20px" }}>PAYMENT & RENEWAL HISTORY</p>
                <div className="table-responsive">
                  <table className="payment-history-table">
                    <thead>
                      <tr>
                        <th>Payment Date</th>
                        <th>Amount</th>
                        <th>Payment Mode</th>
                        <th>Renewed By</th>
                        <th>Notes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedPhotographer.paymentHistory && selectedPhotographer.paymentHistory.length ? (
                        selectedPhotographer.paymentHistory.map((ph, idx) => (
                          <tr key={idx}>
                            <td>{ph.date}</td>
                            <td>₹{ph.amount}</td>
                            <td>{ph.paymentMode}</td>
                            <td>{ph.renewedBy}</td>
                            <td>{ph.notes || "-"}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="5" style={{ fontStyle: "italic", color: "var(--text-muted)" }}>No previous payment records found.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <div style={{ display: "flex", gap: "10px", marginTop: "20px", flexWrap: "wrap" }}>
                  <button className="btn gold small" onClick={() => setModal("renewSubscription")}>
                    <Clock size={14} /> Renew Subscription (+30 Days)
                  </button>
                  <button className="btn ghost small" onClick={() => setModal("editPhotographer")}>
                    <Edit size={14} /> Edit Details
                  </button>
                  <button className="btn ghost small" onClick={() => togglePhotographerStatus(selectedPhotographer.id)}>
                    <Power size={14} /> {selectedPhotographer.isActive ? "Deactivate Account" : "Activate Account"}
                  </button>
                  <button className="btn ghost small danger" onClick={() => deletePhotographer(selectedPhotographer.id)}>
                    <Trash2 size={14} /> Delete Account
                  </button>
                </div>
              </>
            )}

            {modal === "profile" && (
              <>
                <p className="eyebrow">ACCOUNT SETTINGS</p>
                <h2>My Profile</h2>
                <form onSubmit={updateProfile}>
                  <label>Full name
                    <input name="name" defaultValue={user?.name || ""} required />
                  </label>
                  <label>Email address
                    <input name="email" type="email" defaultValue={user?.email || ""} required />
                  </label>
                  <label>New Password (leave blank to keep current)
                    <input name="newPassword" type="password" minLength="8" placeholder="••••••••" />
                  </label>
                  <button className="btn gold" disabled={busy}>Save changes</button>
                </form>
              </>
            )}

            {/* QUOTATION EDITOR MODAL (Photographer Only) */}
            {modal === "editQuote" && activeQuote && (
              <>
                <p className="eyebrow">PHOTOGRAPHER QUOTATION BUILDER</p>
                <h2>Edit Quotation for {activeQuote.customerName}</h2>
                <form onSubmit={saveQuotation}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Studio / Business Name
                      <input name="studioName" defaultValue={activeQuote.customization?.studioName || user?.studioName || user?.name || "Wedding Memories Studio"} required />
                    </label>
                    <label>Contact Phone
                      <input name="contactPhone" defaultValue={activeQuote.customization?.contactPhone || user?.mobile || activeQuote.phone || ""} placeholder="+91 9876543210" />
                    </label>
                  </div>
                  <label>Contact Email
                    <input name="contactEmail" type="email" defaultValue={activeQuote.customization?.contactEmail || user?.email || ""} required />
                  </label>
                  <label>Package Name
                    <input name="packageName" defaultValue={activeQuote.customization?.packageName || "Complete Wedding Package"} required />
                  </label>
                  <label>Package Description
                    <textarea name="packageDescription" defaultValue={activeQuote.customization?.packageDescription || "Full day coverage with high resolution photos and video highlights."} />
                  </label>

                  <p className="eyebrow" style={{ marginTop: "10px" }}>SERVICES INCLUDED & PRICING (₹)</p>
                  <div className="services-editor-list">
                    {editServices.map((srv, idx) => (
                      <div className="service-edit-item" key={idx}>
                        <label>
                          <input type="checkbox" checked={srv.enabled} onChange={() => toggleService(idx)} />
                          <span>{srv.name}</span>
                        </label>
                        <input
                          type="number"
                          value={srv.price}
                          onChange={e => updateServicePrice(idx, e.target.value)}
                          placeholder="Price (₹)"
                          disabled={!srv.enabled}
                        />
                      </div>
                    ))}
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginTop: "10px" }}>
                    <label>Discount Amount (₹)
                      <input name="discount" type="number" defaultValue={activeQuote.customization?.discount || 0} />
                    </label>
                    <label>Advance Payment Paid (₹)
                      <input name="advanceAmount" type="number" defaultValue={activeQuote.customization?.advanceAmount || 0} />
                    </label>
                  </div>

                  <label>Terms & Conditions
                    <textarea name="terms" defaultValue={activeQuote.customization?.terms || "1. 50% advance to confirm booking.\n2. Raw photos delivered within 48 hours.\n3. Final album & video delivered within 3 weeks."} />
                  </label>

                  <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                    <button className="btn gold" disabled={busy}>Save Quotation</button>
                    <button className="btn ghost" type="button" onClick={() => setModal("previewQuote")}>
                      <Eye size={15} /> Preview Client View
                    </button>
                  </div>
                </form>
              </>
            )}

            {/* QUOTATION PREVIEW & CLIENT VIEW MODAL */}
            {modal === "previewQuote" && activeQuote && (
              <>
                <p className="eyebrow">CLIENT QUOTATION PREVIEW</p>
                <h2>Quotation Preview</h2>

                <div className="quote-preview-box">
                  <div className="quote-preview-header">
                    <div>
                      {(user?.logoUrl || activeQuote.photographerLogo) ? (
                        <img
                          src={getImageUrl(user?.logoUrl || activeQuote.photographerLogo)}
                          alt="Studio Logo"
                          className="preview-logo-img"
                        />
                      ) : (
                        <div className="preview-studio-name">{activeQuote.customization?.studioName || user?.studioName || user?.name || "Wedding Memories Studio"}</div>
                      )}
                      {(user?.logoUrl || activeQuote.photographerLogo) && (
                        <div className="preview-studio-name" style={{ fontSize: "18px", marginTop: "6px" }}>
                          {activeQuote.customization?.studioName || user?.studioName || user?.name || "Wedding Memories Studio"}
                        </div>
                      )}
                    </div>
                    <div className="preview-contact">
                      <div><b>Phone:</b> {activeQuote.customization?.contactPhone || user?.mobile || user?.email}</div>
                      <div><b>Email:</b> {activeQuote.customization?.contactEmail || user?.email}</div>
                      <div><b>Date Issued:</b> {new Date().toLocaleDateString()}</div>
                    </div>
                  </div>

                  <div className="preview-meta">
                    <div>
                      <h4>PREPARED FOR</h4>
                      <div><b>Client:</b> {activeQuote.customerName}</div>
                      <div><b>Contact:</b> {activeQuote.phone || activeQuote.email}</div>
                    </div>
                    <div>
                      <h4>EVENT DETAILS</h4>
                      <div><b>Event Date:</b> {activeQuote.eventDate}</div>
                      <div><b>Venue / Location:</b> {activeQuote.venue}</div>
                    </div>
                  </div>

                  <h4>{activeQuote.customization?.packageName || "Wedding Photography Package"}</h4>
                  <p style={{ color: "#555", fontSize: "12px", marginBottom: "15px" }}>
                    {activeQuote.customization?.packageDescription || "Full day professional wedding coverage."}
                  </p>

                  <table className="preview-table">
                    <thead>
                      <tr>
                        <th>Service / Included Item</th>
                        <th style={{ textAlign: "right" }}>Price (₹)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(activeQuote.customization?.servicesList || editServices)
                        .filter(s => s.enabled)
                        .map((s, idx) => (
                          <tr key={idx}>
                            <td>{s.name}</td>
                            <td style={{ textAlign: "right" }}>₹{s.price}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>

                  {(() => {
                    const srvs = (activeQuote.customization?.servicesList || editServices).filter(s => s.enabled);
                    const subtotal = srvs.reduce((acc, s) => acc + (Number(s.price) || 0), 0);
                    const discount = Number(activeQuote.customization?.discount) || 0;
                    const total = Math.max(0, subtotal - discount);
                    const advance = Number(activeQuote.customization?.advanceAmount) || 0;
                    const balance = Math.max(0, total - advance);

                    return (
                      <div className="preview-summary">
                        <div className="summary-row">
                          <span>Subtotal:</span>
                          <span>₹{subtotal}</span>
                        </div>
                        {discount > 0 && (
                          <div className="summary-row" style={{ color: "#2e7d32" }}>
                            <span>Discount:</span>
                            <span>-₹{discount}</span>
                          </div>
                        )}
                        <div className="summary-row total">
                          <span>Total Amount:</span>
                          <span>₹{total}</span>
                        </div>
                        {advance > 0 && (
                          <div className="summary-row">
                            <span>Advance Paid:</span>
                            <span>-₹{advance}</span>
                          </div>
                        )}
                        <div className="summary-row balance">
                          <span>Balance Due:</span>
                          <span>₹{balance}</span>
                        </div>
                      </div>
                    );
                  })()}

                  <div className="preview-terms">
                    <b>TERMS & CONDITIONS:</b>
                    <div style={{ whiteSpace: "pre-line", marginTop: "4px" }}>
                      {activeQuote.customization?.terms || "Standard photography terms apply."}
                    </div>
                  </div>
                </div>

                <div className="share-buttons-row">
                  <button className="btn gold" onClick={() => window.print()}>
                    <Printer size={15} /> Print / Save PDF
                  </button>
                  <button className="btn ghost" onClick={() => shareWhatsApp(activeQuote)}>
                    <Share2 size={15} /> Share via WhatsApp
                  </button>
                </div>
              </>
            )}

            {/* CLIENT REQUEST QUOTATION MODAL (NO LOGIN REQUIRED) */}
            {modal === "quote" && (
              <>
                <p className="eyebrow">TELL US ABOUT YOUR DAY</p>
                <h2>Request Quotation</h2>
                <form onSubmit={createQuote}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    <label>Your Full Name *
                      <input name="customerName" required placeholder="Enter your name" />
                    </label>
                    <label>Your Mobile Number *
                      <input name="phone" required placeholder="9876543210" maxLength="10" />
                    </label>
                  </div>

                  <label>Your Email Address (Optional)
                    <input name="email" type="email" placeholder="client@example.com" />
                  </label>

                  <label>Select Photographer / Studio
                    <select
                      value={selectedPhotographerId}
                      onChange={e => {
                        setSelectedPhotographerId(e.target.value);
                        const photog = publicPhotographers.find(p => p.id === e.target.value);
                        if (photog && photog.servicesList && photog.servicesList.length > 0) {
                          setSelectedServicesList(photog.servicesList.filter(s => s.enabled).map(s => s.name));
                        }
                      }}
                    >
                      {publicPhotographers.length > 0 ? (
                        publicPhotographers.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.studioName || p.name} ({p.city || "Studio Photographer"})
                          </option>
                        ))
                      ) : (
                        <option value="">Any Available Photographer</option>
                      )}
                    </select>
                  </label>

                  <p className="eyebrow" style={{ marginTop: "8px" }}>SELECT SERVICES NEEDED</p>
                  <div className="services-editor-list">
                    {availableServicesForClient.map((srv, idx) => (
                      <div className="service-edit-item" key={idx}>
                        <label>
                          <input
                            type="checkbox"
                            checked={selectedServicesList.includes(srv.name)}
                            onChange={() => toggleClientSelectedService(srv.name)}
                          />
                          <span>{srv.name}</span>
                        </label>
                        <span style={{ color: "var(--color-primary)", fontSize: "13px", fontWeight: "600" }}>₹{srv.price}</span>
                      </div>
                    ))}
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginTop: "8px" }}>
                    <label>Wedding Date *
                      <input name="eventDate" type="date" required />
                    </label>
                    <label>Venue / City *
                      <input name="venue" required placeholder="Hotel Sun, Mumbai / Dhule" />
                    </label>
                  </div>

                  <label>Extra Details / Requirements
                    <textarea name="notes" placeholder="Tell us specific requirements, guest count, etc." />
                  </label>

                  <button className="btn gold" disabled={busy}>Send Quotation Request</button>
                </form>
              </>
            )}

            {modal === "wedding" && role === "photographer" && (
              <>
                <p className="eyebrow">CREATE A GALLERY</p>
                <h2>New wedding</h2>
                <form onSubmit={createWedding}>
                  <label>Wedding / Couple name<input name="title" required placeholder="Aarav & Anaya" /></label>
                  <label>Event date<input name="eventDate" type="date" /></label>
                  <label>Venue<input name="venue" /></label>
                  <label>Description<input name="description" /></label>
                  <button className="btn gold" disabled={busy}>Create gallery + QR</button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Sparkle() { return <Heart size={14} />; }
function Brand({ onClick }) {
  return (
    <a className="brand" onClick={onClick}>
      <span className="brand-icon"><Camera size={22} /></span>
      <span>WEDDING <b>MEMORIES</b></span>
    </a>
  );
}

function QuoteList({ items = [], onView, isPhotographer = false, onEdit, onPreview, onDelete }) {
  return (
    <div className="quote-list">
      {items.length ? items.map(q => (
        <article key={q.id}>
          <div>
            <b>{q.customerName}</b> {q.phone ? `(${q.phone})` : ""}
            <p>{q.eventDate} · {q.venue} · Services: {q.services}</p>
            <small>{q.status} {q.viewedAt ? "· Viewed" : "· Not viewed yet"}</small>
          </div>
          <div className="quote-actions">
            {isPhotographer ? (
              <>
                <button className="btn ghost small" onClick={() => onEdit(q)}>
                  <FileText size={14} /> Edit Quotation
                </button>
                <button className="btn gold small" onClick={() => onPreview(q)}>
                  <Eye size={14} /> Preview & Share
                </button>
                {onDelete && (
                  <button className="btn ghost small danger" onClick={() => onDelete(q.id)}>
                    <Trash2 size={14} /> Delete
                  </button>
                )}
              </>
            ) : (
              <>
                <button className="btn ghost small" onClick={() => onView(q.id)}>
                  <Eye size={14} /> Mark viewed
                </button>
                {onDelete && (
                  <button className="btn ghost small danger" onClick={() => onDelete(q.id)}>
                    <Trash2 size={14} /> Delete
                  </button>
                )}
              </>
            )}
          </div>
        </article>
      )) : <p className="muted">No quotations yet.</p>}
    </div>
  );
}

function PhotographerForm({ api, setNotice, onCreated }) {
  const [open, setOpen] = useState(false);
  async function submit(e) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.currentTarget).entries());
    try {
      await api("/photographers", { method: "POST", body: JSON.stringify(body) });
      setNotice("Photographer account created.");
      e.target.reset();
      setOpen(false);
      if (onCreated) onCreated();
    } catch (err) {
      setNotice(err.message);
    }
  }
  return (
    <div className="photographer-admin">
      <button className="btn ghost" onClick={() => setOpen(!open)}>
        <Users size={16} /> {open ? "Hide form" : "Create photographer account"}
      </button>
      {open && (
        <form onSubmit={submit}>
          <label>Name<input name="name" required /></label>
          <label>Email<input name="email" type="email" required /></label>
          <label>Temporary password<input name="password" minLength="8" required /></label>
          <button className="btn gold">Create account</button>
        </form>
      )}
    </div>
  );
}

export default App;
